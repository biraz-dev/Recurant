# Royal mummy animation prototype — reference 141

**Generated animation prototype, not a rigged or production-polished character.**

This is a separate royal mummy, with aged linen wrappings and muted gold/blue/red headband, collar and belt. It does not replace any earlier mummy kit. No weapon is included.

96 generated poses: **4 views × 4 actions × 6 frames**. All runtime and master PNGs use genuine RGBA transparency. Image generation created the artwork; Python only isolated, cropped, aligned, resized and packaged it.

## Claude / engine integration

1. Read `extracted/manifest.json`. It contains every frame ID, relative path, atlas rectangle, pivot, frame duration, FPS, loop flag and proposed strike frame.
2. Prefer `extracted/atlases128/{front,back,left,right}.png` for runtime. Each atlas is **768×512**, with 128×128 cells in 6 columns × 4 rows.
3. Master atlases are in `extracted/atlases256/`: **1536×1024**, with 256×256 cells. Individual PNGs are in `frames128/` and `frames256/`. Native-sized cutouts are retained in `native/`.
4. Atlas rows, top to bottom: `walk`, `claw_swipe`, `lunge`, `two_hand_slam`. Columns are frames **0–5**.
5. Front = down/toward camera; back = up/away; left/right = screen direction. Four independent generated views, not mirrored copies.
6. Ground pivot: **(128,232)** at 256px; **(64,116)** at 128px; normalized **(0.5,0.90625)**. Use this same anchor for every frame. Do not fit each frame independently to its visible bounds.
7. Walk loops. Attacks play once and return to walk. Reuse walk frame 0 only if a placeholder idle is needed; there is no additional generated idle animation.

| Action | FPS | Duration per frame | Proposed impact frame, zero-based |
|---|---:|---:|---:|
| walk | 8 | 125 ms | none |
| claw_swipe | 10 | 100 ms | 3 |
| lunge | 10 | 100 ms | 3 |
| two_hand_slam | 8 | 125 ms | 4 |

**Timings and impact frames are gameplay proposals, not measured physical contacts.** Drive movement, collision and hitboxes separately in the engine. These sprites contain no root-motion, weapon, hit effects or collision data. Add root movement yourself for the lunge.

Paths in `manifest.json` are relative to `extracted/`. Paths in `PROVENANCE.json` are relative to the kit root. Use nearest filtering for a crisper sprite presentation, or linear filtering if the target game prefers smoother downsampled edges; preview at the actual intended screen scale.

## Previews

`extracted/previews/` includes:
- 16 individual view/action GIFs.
- `walk_four_views.gif` and `attacks_four_views.gif` (18 GIFs total).
- `all_frames_contact.png` (all 96 poses).
- `alpha_light_check.png` (selected silhouettes on a light background).
- Static first-frame versions of the four-view montages.

Backgrounds, labels and baselines appear only in previews, never in the transparent sprite assets. GIF timings are quantized to centiseconds: 125 ms becomes 120 ms. The combined attack montage uses the same 120 ms display interval for all rows to make comparison easy; use the manifest's individual animation FPS in-game.

## QA and known limitations

Automated checks confirm:
- 96 native cutouts, 96 master frames, 96 runtime frames and 8 atlases.
- All **192 atlas tiles byte-match** their corresponding frame PNGs.
- All frames are RGBA with transparent pixels; no opaque background rectangle.
- **Zero edge-touching frames** and no strong-alpha contact at any generated sheet's outer canvas edge.
- One global source-to-master scale of **0.548** across all 96 poses; no per-frame resizing to fit.
- Minimum master margins L/T/R/B: **15 / 77 / 13 / 24 px**.
- 18 six-frame animated GIFs, valid relative manifest paths and all expected animation entries.

Visual review covered all 96 extracted poses plus selected silhouettes on a light background. Rear views show the back of the wrapped head, not a front face. Side attack heads remain facing the intended screen direction; extended attacks point that way. No obvious extra limbs or clipped bandage silhouettes were found.

This remains an **AI-generated pose animation prototype**: bandage placement, jewelry and body proportions vary a little frame-to-frame. Some side attack torsos rotate toward three-quarter view. Walk motion is a readable shamble, not a physically verified planted-foot gait; slight foot sliding, scale/proportion variation and transition pops may remain. Mechanical ground alignment does not constitute a rig or guarantee perfect temporal continuity. Inspect the GIFs in the target engine before shipping. A hand-authored cleanup/rigging pass is recommended for production.

## Source artwork and rebuild

- Supplied identity reference: `sources/reference.png` (reference 141).
- Native generated sheets: `art/*-source-v1.png`.
- Selected source mapping: `art/sources.json`.
- Exact generation prompts: `art/prompts/{front,back,left,right}.txt`.
- Generator and SHA-256 provenance: `PROVENANCE.json`.
- Mechanical crop/align implementation: `art/extract_align.py`.
- Raw component analysis: `art/raw_analysis.json`.
- Extraction checks: `extracted/extraction_qa.json`.
- Package and visual review checks: `QA.json`.

Rebuild with Python plus Pillow, NumPy and SciPy installed, from the kit root:

```sh
python art/extract_align.py --source-dir art --output-dir extracted --sources-json art/sources.json --asset royal_mummy
```

The extractor isolates each connected character using source alpha, keeps nearby disconnected details and a narrow original-alpha fringe, and removes distant/faint background haze. It preserves the selected native pixels without repainting. It then applies one uniform scale, a lower-body horizontal anchor and a bottom/ground anchor. Original reference and generated sheets are retained unchanged.

No external upload, publication or repository change is part of this package.
