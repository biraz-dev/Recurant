# Ember skeleton — four-direction animation kit

Based on `134.png`: a bare charred skeleton with internal coal embers, not the earlier fleshy undead character. **96 generated prototype poses**: four headings × four actions × six frames.

## Give Claude these files

1. `docs/CLAUDE_INTEGRATION.md` — import instructions and animation behavior.
2. `frames/manifest.json` — authoritative paths, frame order, timing, pivots and atlas rectangles.
3. `frames/atlases128/` **or** `frames/frames128/` — game-ready file layout, not production-verified motion.

Start with `frames/previews/walk_four_views.gif` and `frames/previews/attacks_four_views.gif`. Preview GIFs use an opaque background; the actual PNG assets have transparent alpha.

## Included

- `frames/frames128/`: 96 transparent 128 × 128 PNG runtime frames.
- `frames/frames256/`: 96 matching transparent 256 × 256 aligned masters.
- `frames/atlases128/`: four 768 × 512 exact-tile atlases.
- `frames/atlases256/`: four 1536 × 1024 exact-tile atlases.
- `frames/native/`: 96 extracted cutouts at their original pixel dimensions.
- `frames/previews/`: 18 six-frame GIFs, four-view previews, every-frame contact sheet, and light-background alpha inspection.
- `frames/manifest.json`: shared schema with the first character kit.
- `frames/extraction_qa.json` and `frames/independent_qa.json`: measured output checks.
- `art/originals/`: all five generated source sheets, including superseded left-view v1; selected variants in `sources.json`.
- `art/generation-prompts.json` and `art/provenance.json`: exact prompts, selected sources and checksums.
- `scripts/extract_align.py`: reproducible mechanical extraction, alignment and resizing.
- `134.png`: supplied reference, preserved unchanged.

## Important limitations

These are generated 2D animation poses, **not a rigged or physically verified character**. Side walks can read as a shuffle; small anatomy/texture details vary; some attack torsos rotate toward three-quarter view. Review at the intended game scale and hand-polish before a final release. Attack damage frames are proposed tuning values, not measured collision events. No separate idle, death, hit-react, run or diagonal animation has been invented or included.

All 192 master/runtime PNGs were checked for genuine alpha and transparent margins; no frame touches an edge, and all 192 atlas tiles exactly match their standalone files. The source sheets are **not safe for blind grid slicing**: use the aligned atlases or individual frames instead. Component-aware extraction preserves extended claws/limbs and excludes unrelated faint background haze; untouched native sheets remain available.

## Rebuild

From this kit's root, with Python 3, Pillow, NumPy and SciPy installed:

```sh
python3 scripts/extract_align.py \
  --source-dir art/originals \
  --output-dir frames \
  --sources-json art/originals/sources.json \
  --asset ember_skeleton
```

Artwork was generated using the built-in image-generation tool. Python only isolated, aligned, resized, packed and previewed the generated sprites, as authorized; it did not paint the character.
