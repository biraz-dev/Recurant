# v02 provenance

Created 2026-10-28 as a separate second-revision asset kit.

## Requested change

This revision uses more dynamic movement and one large single swinging movement. The revision retains the restrained original sword design while changing the attack choreography and actual arm/hand poses.

## Native artwork generation

- Tool: built-in `image_gen.imagegen`, transparent background enabled.
- Prompt: `docs/prompt-01.txt`.
- Design reference input: `source/v01-idle-design-reference.png`; retained only as source reference, not as a v01 runtime pack.
- Source output: `source/sword-broad-swing-source-v01.png`.
- No commercial game images or extracted sprites were supplied.
- One new native source generation was sufficient for this bounded revision; no alternate result was silently substituted.

The generation drew genuinely new raised-arm, extended-arm, crossed-screen follow-through and lowered-reset poses. The code did not rotate or paint v01 art to fake new motion.

## Mechanical registration

Equal 362 × 362 cells were cropped, all uniformly resized to 264 × 264 with nearest-neighbor, then translated on exact 320 × 240 transparent canvases using measured hand landmarks and a deliberate large swing path. This is a common scale, not independent bounding-box fitting.

Frame 11 reuses frame 00 to return to identical idle. Frame 07 is intentionally almost empty because the weapon has moved below the screen. Other intentional offscreen action is listed in the JSON manifest.

Only approved crop/resize/align, assembly, metadata, and preview compositing were done in Python/Pillow. No alpha thresholding, per-frame rotation, synthetic motion blur, or painted repair was used. The original generated alpha/color is retained under nearest resampling.

## Verification and caveats

- All final PNG frames are RGBA 320 × 240.
- Native and enlarged GIF frame counts, dimensions and durations are checked.
- Idle and lowered-reset central-view checks pass.
- The hand path travels roughly 278 px from maximum windup to the lower-left finish.
- The contact sheet was visually inspected for coherent single-swing progression and source-edge registration.
- v01 frame hashes still match its original manifest.
- The final set remains an AI-generated visual prototype with minor inter-frame design drift and edge fringe; no engine/gameplay validation has been performed.

