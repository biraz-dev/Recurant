#!/usr/bin/env python3
"""v02: register native generated broad-swing poses; no painted or rotated art."""
from pathlib import Path
import hashlib,json,math,zipfile
import numpy as np
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parent
W,H=320,240
CELL=362; SCALED=264; SCALE=SCALED/CELL
SOURCE=ROOT/"source/sword-broad-swing-source-v01.png"
LANDMARKS=[(295.5,304.1),(306.1,254.2),(310.6,187.6),(256.1,265.9),
           (260.7,214.5),(173.0,247.8),(73.2,308.4),(293.1,333.4),
           (299.2,337.2),(277.1,281.5),(289.9,283.6)]
# Large arm-driven arc. Source edge constraints are respected: arm cuts remain
# outside the viewport; deliberate blade exits remain at/beyond screen edges.
TARGETS=[(272,214),(290,180),(305,153),(270,179),(246,194),(121,219),
         (45,252),(270,270),(249,252),(260,235),(267,218)]
NAMES=["idle","draw_back","maximum_windup","release","contact","wide_follow_through",
       "finish_offscreen","lowered_reset","return_low","raise","settle","idle_return"]
ATTACK_DURATIONS=[110,100,30,30,40,60,90,100,90,80,100]
PREVIEW_DURATIONS=[700]+ATTACK_DURATIONS[:-1]+[550]
BG=(38,42,43,255)
for d in ["frames","previews","docs"]: (ROOT/d).mkdir(exist_ok=True)
source=Image.open(SOURCE).convert("RGBA")
assert source.size==(1448,1086)
frames=[];meta=[]
for i in range(11):
    col,row=i%4,i//4
    rect=(col*CELL,row*CELL,(col+1)*CELL,(row+1)*CELL)
    cell=source.crop(rect).resize((SCALED,SCALED),Image.Resampling.NEAREST)
    landmark=tuple(round(v*SCALE) for v in LANDMARKS[i])
    offset=tuple(TARGETS[i][a]-landmark[a] for a in range(2))
    frame=Image.new("RGBA",(W,H))
    frame.alpha_composite(cell,offset)
    frames.append(frame)
    meta.append({"index":i,"name":NAMES[i],"file":f"frames/sword_v02_{i:02d}_{NAMES[i]}.png",
                 "source_cell_index":i,"source_cell_rect_px":list(rect),
                 "measured_source_hand_landmark_px":list(LANDMARKS[i]),
                 "scaled_hand_landmark_px":list(landmark),
                 "target_hand_landmark_px":list(TARGETS[i]),
                 "canvas_translation_px":list(offset),
                 "atlas_rect_px":[col*W,row*H,W,H]})
frames.append(frames[0].copy())
meta.append({**meta[0],"index":11,"name":NAMES[11],
             "file":"frames/sword_v02_11_idle_return.png","identical_to_frame":0,
             "atlas_rect_px":[960,480,W,H]})
atlas=Image.new("RGBA",(1280,720))
qa=[]
for i,(f,m) in enumerate(zip(frames,meta)):
    f.save(ROOT/m["file"]);atlas.alpha_composite(f,((i%4)*W,(i//4)*H))
    a=np.array(f.getchannel("A")); yy,xx=np.nonzero(a>64)
    bounds=[int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)] if len(xx) else None
    m["visible_bounds_alpha_gt_64_px"]=bounds
    m["png_sha256"]=hashlib.sha256((ROOT/m["file"]).read_bytes()).hexdigest()
    qa.append({"frame":i,"size":list(f.size),"mode":f.mode,"bounds_alpha_gt_64_px":bounds,
               "alpha_zero_fraction":round(float((a==0).mean()),6),
               "edge_visible_pixel_counts":{"top":int((a[0,:]>64).sum()),
                 "left":int((a[:,0]>64).sum()),"right":int((a[:,-1]>64).sum()),
                 "bottom":int((a[-1,:]>64).sum())}})
atlas.save(ROOT/"sword_v02_atlas_4x3.png")
frames[0].save(ROOT/"sword_v02_idle.png")
frames[4].save(ROOT/"sword_v02_contact.png")
flat=[]
for f in frames:
    bg=Image.new("RGBA",(W,H),BG);bg.alpha_composite(f);flat.append(bg.convert("RGB"))
for size,name in [((320,240),"sword_v02_attack_320x240.gif"),((960,720),"sword_v02_attack_3x_nearest.gif")]:
    seq=[f.resize(size,Image.Resampling.NEAREST) for f in flat]
    seq[0].save(ROOT/"previews"/name,save_all=True,append_images=seq[1:],
                duration=PREVIEW_DURATIONS,loop=0,disposal=2,optimize=False)
frames[0].save(ROOT/"previews/sword_v02_attack_transparent.webp",save_all=True,
               append_images=frames[1:],duration=PREVIEW_DURATIONS,loop=0,
               lossless=True,quality=100,method=6)
contact=Image.new("RGBA",(1280,804),BG);draw=ImageDraw.Draw(contact)
try: font=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",12)
except OSError: font=ImageFont.load_default()
for i,f in enumerate(frames):
    x=i%4*320;y=i//4*268;contact.alpha_composite(f,(x,y))
    draw.text((x+8,y+246),f"{i:02} {NAMES[i].replace('_',' ')}"+(" / HIT" if i==4 else ""),
              font=font,fill=(215,220,219,255))
contact.convert("RGB").save(ROOT/"previews/sword_v02_contact_sheet.png")
frames[0].resize((960,720),Image.Resampling.NEAREST).save(ROOT/"previews/sword_v02_idle_3x.png")
frames[4].resize((960,720),Image.Resampling.NEAREST).save(ROOT/"previews/sword_v02_contact_3x.png")
timeline=[];t=0
for i,duration in zip(range(1,12),ATTACK_DURATIONS):
    item={"frame_index":i,"start_ms":t,"duration_ms":duration}
    if i==4:item["events_on_enter"]=["melee_impact"]
    timeline.append(item);t+=duration
manifest={
 "asset_id":"recurant_plain_sword_fp_prototype_v02","revision":"broad_single_swing",
 "status":"animation_prototype","viewport_px":[320,240],
 "render":{"type":"first_person_screen_overlay","canvas_origin_px":[0,0],
           "anchor":"bottom_right","anchor_px":[320,240],"normalized_anchor":[1,1],
           "filter":"nearest","alpha":"straight / unpremultiplied",
           "disable_trim":True,"pixel_snap":True},
 "atlas":{"file":"sword_v02_atlas_4x3.png","size_px":[1280,720],"columns":4,"rows":3,
          "frame_size_px":[320,240],"order":"row_major","padding_px":0},
 "idle":{"frame_index":0,"loop":True,"duration_ms":None},
 "attack":{"loop":False,"duration_ms":t,"return_state":"idle","timeline":timeline,
           "events":[{"name":"melee_impact","frame_index":4,"time_ms":240,
                      "fires_once_per_attack":True}],
           "proposed_hit_window_ms":[240,270],
           "swing_motion_interval_ms":[210,370],
           "note":"One high-right to low-left cut. Recovery stays below view then rises on the right; not a reverse slash. Gameplay collision/damage not implemented."},
 "preview":{"native_gif":"previews/sword_v02_attack_320x240.gif",
            "nearest_3x_gif":"previews/sword_v02_attack_3x_nearest.gif",
            "rgba_webp":"previews/sword_v02_attack_transparent.webp",
            "frame_durations_ms":PREVIEW_DURATIONS,"background_rgb":list(BG[:3]),
            "note":"Opaque background is GIF preview only. Long idle holds are preview-only."},
 "registration":{"source":"source/sword-broad-swing-source-v01.png",
                 "source_size_px":list(source.size),"source_cell_px":[362,362],
                 "common_scaled_cell_px":[264,264],"uniform_scale":SCALE,
                 "method":"Equal source-cell crops, one common uniform nearest scale, measured-landmark integer canvas placement",
                 "no_per_pose_scaling":True,"no_per_pose_rotation":True,"no_bounds_fitting":True,
                 "no_drawn_artwork_or_color_edits_by_code":True,
                 "note":"Generated source used square cells despite requested 4:3 cells. Uniform scale preserves blade proportions; every final canvas is exact 320x240."},
 "intentional_offscreen_action":{"2":"Raised backswing can exit top/right.",
                               "5":"Blade exits left during the committed follow-through.",
                               "6":"Hand and sword exit lower-left as the same swing finishes.",
                               "7":"Weapon resets below the viewport; central view is empty.",
                               "8":"Hand begins below screen; sword re-enters low on the right.",
                               "all":"Forearm/sleeve may exit bottom/right."},
 "frames":meta,
 "limitations":["Minor native AI-drawn silhouette, guard and edge-fringe drift remains.",
                "Hand landmarks are approximate registration points; offscreen landmarks can lie outside the canvas.",
                "This is a visual animation prototype, not a skeletal or hand-cleaned final animation.",
                "Timing and hit event are proposals; no engine integration or gameplay collision test."]
}
(ROOT/"sword_v02_animation.json").write_text(json.dumps(manifest,indent=2)+"\n")
idle=np.array(frames[0].getchannel("A"));reset=np.array(frames[7].getchannel("A"))
report={"source_sha256":hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        "frame_count":12,"all_frames_rgba_320x240":all(f.mode=="RGBA" and f.size==(320,240) for f in frames),
        "idle_return_pixel_identical":frames[0].tobytes()==frames[11].tobytes(),
        "idle_reticle_area_20x20_has_alpha_gt_64":bool((idle[110:130,150:170]>64).any()),
        "lowered_reset_center_160x120_has_alpha_gt_64":bool((reset[60:180,80:240]>64).any()),
        "committed_swing_hand_travel_px":{"from_frame":2,"to_frame":6,
             "start":list(TARGETS[2]),"end":list(TARGETS[6]),
             "straight_line_distance":round(math.dist(TARGETS[2],TARGETS[6]),2)},
        "attack_duration_ms":t,"impact_time_ms":240,"frames":qa,
        "native_artwork_tool":"builtin image_gen","alpha_thresholding_applied":False,
        "art_operations":"common crop/resize, integer screen alignment, no rotation or drawing"}
(ROOT/"docs/qa-report.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({k:v for k,v in report.items() if k!="frames"},indent=2))

