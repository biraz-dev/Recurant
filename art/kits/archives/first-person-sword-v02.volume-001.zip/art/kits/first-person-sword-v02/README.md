# Recurant — sword v02: one broad committed swing

Revision goal: a more dynamic attack with one large, single swinging movement.

This version replaces the small wrist-driven action with newly generated arm and wrist poses: a high-right draw-back, one fast sweep across the view, a far lower-left follow-through, then a lowered reset before the sword rises quietly on the right.

The plain steel blade, compact straight guard, dark leather grip, bare right hand, and charcoal sleeve remain restrained. No glow, spikes, decorative effects, duplicate blade, or motion streaks.

**Every final overlay frame is transparent RGBA, exactly 320 × 240.** v01 was preserved separately and was not overwritten.

## Review files

- `previews/sword_v02_attack_320x240.gif` — native-resolution loop.
- `previews/sword_v02_attack_3x_nearest.gif` — 960 × 720 nearest-neighbor enlargement.
- `previews/sword_v02_contact_sheet.png` — all poses, labeled only in the preview.
- `previews/sword_v02_attack_transparent.webp` — optional lossless full-alpha animation.
- `sword_v02_idle.png`, `sword_v02_contact.png` — transparent screen overlays.
- `frames/` — twelve 320 × 240 PNGs, including exact idle-return reuse.
- `sword_v02_atlas_4x3.png` — 1280 × 720 transparent atlas.
- `sword_v02_animation.json` — timing, proposed hit event, frame rectangles, anchors, registration.
- `docs/qa-report.json` — verification results.
- `build_sword_v02.py` — reproducible mechanical crop/resize/align pipeline.

The GIFs have an opaque gray preview background. The PNGs, atlas, and animated WebP do not. Preview loops include longer idle holds than the game sequence.

## Motion and timing

The committed swing moves the approximate hand landmark from **(305,153)** at maximum windup to **(45,252)** at the offscreen lower-left finish: about **278 pixels** of travel. The hand crosses left during follow-through; it does not stay pinned at the wrist.

- Full proposed attack: **830 ms**.
- Windup: **210 ms**.
- Fast cutting motion: **160 ms**, from attack time 210 to 370 ms.
- Proposed impact: **frame 04, at 240 ms**.
- Proposed hit window: **240–270 ms**.
- Recovery and return: **460 ms**, mostly below the center of view.
- Frame 11 is an exact copy of frame 00.

| Index | Pose | Attack duration |
|---|---|---:|
| 00 | Held idle | Until input |
| 01 | Draw back | 110 ms |
| 02 | Maximum windup | 100 ms |
| 03 | Release | 30 ms |
| 04 | Contact | 30 ms |
| 05 | Wide follow-through | 40 ms |
| 06 | Finish offscreen | 60 ms |
| 07 | Lowered reset | 90 ms |
| 08 | Return low | 100 ms |
| 09 | Raise | 90 ms |
| 10 | Settle | 80 ms |
| 11 | Idle return | 100 ms |

**Offscreen movement is intentional:** the raised sword may exit top/right in frame 02; the blade exits left in 05; the hand and sword finish through lower-left/bottom in 06; 07 is almost empty; 08 reintroduces the blade while the hand is still below view. These are not accidental clipping errors.

## Rendering and processing

Draw the entire frame at viewport origin `(0,0)`, or use bottom-right anchor `(320,240)` / normalized `(1,1)`. Use nearest sampling, integer screen positions, straight-alpha import settings, and no automatic trimming or visible-bounds centering. Atlas frames have no extrusion padding.

All new poses were drawn by built-in image generation using v01 idle as the design reference. No Python rotations, painted limb extensions, or reused v01 poses masquerade as a new attack.

The source generator returned twelve equal **362 × 362** cells despite the requested 4:3 cell layout. A single uniform **264/362** scale was applied to every source cell, preserving proportions. Integer hand-landmark translations place each into the required transparent 320 × 240 canvas. Source edges that were already cropped remain outside the viewport or at its boundary. No pose was independently fitted or resized.

Rebuild: `python build_sword_v02.py` (Pillow and NumPy). See the manifest for the exact source rectangles, scale, landmarks, and placement translations.

## Prototype limits

The motion is substantially broader, but this is still a **visual animation prototype**, not hand-cleaned final game art. Small AI-drawn silhouette/guard differences and fine edge fringe remain. Timing and impact events are proposals; no engine integration, collision, damage, or sound is implemented.

Inspect the native-size GIF and test in-engine before production adoption. This package provides assets and integration guidance only.

