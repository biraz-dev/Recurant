# Ruins art kit

Start with `qa/asset_contact_sheet.png`. The nine runtime textures are intended for a stylized game implementation, not a recovered original production asset set.

## Recommended runtime files

All paths below are relative to the **kit root**. Every square runtime texture is 256 × 256. `materials` are RGB; `foliage` are genuine RGBA.

| Use | File |
| --- | --- |
| Walls, columns, lintels | `art/runtime/256/materials/sandstone_blocks_basecolor.png` |
| Floor slabs, bridge deck, stairs | `art/runtime/256/materials/worn_floor_basecolor.png` |
| Damp lower walls / moss variation | `art/runtime/256/materials/mossy_stone_basecolor.png` |
| Soil / silt patches | `art/runtime/256/materials/compact_dirt_basecolor.png` |
| Rubble and non-masonry stone | `art/runtime/256/materials/rubble_stone_basecolor.png` |
| Optional stylized water color | `art/runtime/256/materials/water_basecolor.png` |
| Carved trim sheet, explicit UV selection | `art/runtime/256/materials/carved_trim_basecolor.png` |
| Fern crossed-quad card | `art/runtime/256/foliage/fern_cluster_rgba.png` |
| Hanging vine card | `art/runtime/256/foliage/hanging_vines_rgba.png` |

For simpler trim UVs, two **256 × 64 RGB** strip crops are included:

- `art/runtime/256/trim/carved_meander_strip.png`
- `art/runtime/256/trim/carved_diamond_strip.png`

These are semantic crops, not equal quarters of the generated sheet. Source crop coordinates are in `asset_manifest.json`. The original sheet did not follow exact equal-height band instructions. Use the actual crop files rather than assuming quarter-height UV bands.

## Import and material settings

- Import color textures as **sRGB**, use nearest-neighbor magnification for the retro treatment. 256px files are power-of-two, unlike the generated masters.
- The six non-trim square materials are repeat **candidates**, not certified seamless maps. Start at roughly one texture per 2 m and tune the texel density to the scene. Inspect long surfaces and cut joins at masonry breaks when needed.
- For stone/earth, use an ordinary non-metallic material. Roughness around 0.85–1 is a useful starting value, **not a measured material property**. These images contain no actual normal, roughness, metallic, height, displacement, or ambient-occlusion maps. Do not load the RGB color art into those slots.
- Neutral illumination was requested during generation, but some painted dark crevices and bevel contrast remain. Avoid doubling that contrast with heavy SSAO or strong normal maps.
- Trim: clamp vertically. A horizontal repeat is only a candidate and still needs in-engine seam inspection. Do not repeat the full sheet vertically across a wall.
- Foliage: clamp both axes, preserve alpha, use alpha masking around 0.5, and render double-sided. Start with crossed quads for ferns and a vertical card for vines. Use alpha-tested shadow rendering if supported; never let the transparent card cast a solid rectangle. Runtime scaling does not remove genuine native alpha.
- The water PNG is a **stylized color pattern**, not a normal or physically simulated water map. A teal translucent plane with slow UV scrolling is a possible prototype. Actual transparency, reflections, refraction, flow, collision, and underwater color are renderer/gameplay choices, not baked into this file.
- Review mipmapping, minification, alpha cutoff, shadows, and distant flicker inside the selected engine. No engine-specific material or shader was tested here.

## Masters, projections, and provenance

- Untouched generated masters: `art/materials/*.png` and `art/foliage/*.png`, all **1254 × 1254**.
- `art/guides/modular_orthographic_style_reference.png`, **1536 × 1024 RGB**, gives column, doorway, wall, stair, bridge, and seated-relief shape references. It is an **AI orthographic-style concept sheet**, not a set of dimensionally exact, mutually registered projections. Some views retain illustrative depth; do not trace it as CAD. The separate metric mesh/spec files take precedence.
- Every master was generated with the built-in `image_gen.imagegen` tool in a separate call, using `reference/source_concept.png` as the shared style reference. The source was viewed first and is unchanged.
- `generation_prompts.json` preserves the full prompt set. `asset_manifest.json` lists dimensions, alpha checks, file hashes, crop rectangles, runtime derivatives, and edge mismatch diagnostics.
- The user approved crop/resize for implementation. `prepare_runtime.py` performs only nearest-neighbor resizing, explicit trim cropping, and QA layout assembly. It does not repaint, invent maps, or alter the masters.

## Quality checks and limitations

- All ten masters were opened and visually inspected. All nine square runtime textures were reviewed in the contact sheet.
- Both foliage masters contain alpha values spanning 0–255. No border pixel reaches alpha 128; low-opacity fringe pixels can still exist, so inspect the alpha-tested silhouette in the engine.
- `qa/material_repeat_2x2.png` repeats the six non-trim materials without retouching. It exposes the actual center seams rather than hiding them. Materials remain **not certified seamless**. The wall and floor borders have larger discontinuities than the dirt, rock, and water candidates; avoid promising infinite seamless repetition.
- Edge mean absolute differences in the manifest are diagnostics in 0–255 RGB units, not a visual pass/fail score or proof of seamlessness.
- The art is ready for prototype integration and further art direction. It is not an exact reconstruction of hidden surfaces, final authored PBR assets, or a complete animation/VFX/audio/UI pack.

To regenerate runtime derivatives and previews after deliberate master updates:

```sh
python art/prepare_runtime.py
```

Requires Pillow and NumPy. Existing master hashes can be compared with `asset_manifest.json` before regeneration.
