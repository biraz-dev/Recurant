# Wraith animation prototype — reference 138

96 generated poses: 4 views × 4 actions × 6 frames. RGBA PNGs have genuine transparency.

## Claude / engine integration
- Read `extracted/manifest.json` first. Frame IDs, paths, atlas rectangles, pivots, FPS, loop flags and **proposed** zero-based strike frames are explicit.
- Prefer `extracted/atlases128/{front,back,left,right}.png` for runtime; each is 768×512 with 128×128 cells, 6 columns × 4 rows.
- Master atlases `extracted/atlases256/` are 1536×1024 with 256×256 cells. Individual frames in `frames128/` and `frames256/`; native extracted cutouts retained in `native/`.
- Rows in order: hover, claw_swipe, spectral_reach, wail_cast. Columns are frames 0–5.
- Front = down/toward camera; back = up/away; left/right = screen directions. These are independently generated, not mirrored.
- Pivot: master (128,232), runtime (64,116), normalized (0.5,0.90625). For this legless hovering character, this pivot marks the lowest retained robe tendrils, NOT a foot contact. Use a consistent anchor; do not auto-fit each frame to its own bounds.
- FPS and strike timings are starting points only. Drive world movement and collision in the engine; attacks are not actual physics or authoritative hitboxes.
- `extracted/previews/`: 16 action GIFs, four-view locomotion and attack GIFs, contacts. Preview backgrounds/labels are not part of the transparent sprites.

## QA / limitations
Automated QA: 96 masters + 96 runtime frames; atlas crops byte-match every corresponding frame; zero edge-touching frames. One global source-to-master scale = 0.588, never independent per-pose fitting. Minimum frame margins L/T/R/B = [13, 77, 32, 24] px.

These are AI-generated **prototype pose animations**, not a hand-rigged or polished final gait. Some attack poses drift toward three-quarter view, body volume and cloth details vary, and idle is a reused locomotion pose. Inspect the GIFs at your engine's intended speed/scale before shipping.

## Sources and reproducibility
- Original supplied reference: `sources/reference.png`.
- Native generated sheets: `art/*-source-*.png`; selected versions listed in `art/sources.json`. Superseded sources, when present, are kept for provenance only.
- Exact prompts: `art/prompts/`; hashes and provenance: `PROVENANCE.json`.
- Crop/align script: `art/extract_align.py`; raw segmentation report: `art/raw_analysis.json`; final QA: `extracted/extraction_qa.json`.
- Rebuild: `python art/extract_align.py --source-dir art --output-dir extracted --sources-json art/sources.json --asset wraith` (from this kit folder).
