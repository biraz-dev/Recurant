# Demon knight animation prototype

Reference: `reference/135.png`. Generated with built-in imagegen, then mechanically isolated/resized with user-approved Python processing.

- 96 generated frames: 4 views × 4 actions × 6 frames.
- `frames256/`: 256×256 RGBA masters; `frames128/`: 128×128 runtime frames.
- `atlases256/`, `atlases128/`: one 6-column × 4-row atlas per direction. Rows: walk, sword_slash, thrust, shield_bash.
- Ground pivot: (128,232) master, (64,116) runtime; normalized (0.5,0.90625).
- `manifest.json`: every filename, rectangle, duration, FPS and suggested zero-based hit frame. Walk loops; attacks return to walk.
- `previews/`: 16 individual action GIFs, two four-view GIFs and contact sheets. Previews alone have opaque backgrounds/labels.
- `native/`: isolated native-resolution frames. `art/`: raw sheets, prompt set, extraction script and segmentation report.

## QA and limitations
24 separate connected body components were found per sheet, with no strong-alpha source-edge contact. All 192 master/runtime atlas tiles exactly match standalone PNGs. No output frame touches an edge. Segmentation follows each complete component even where weapons cross nominal cell boundaries, rather than blind grid cropping. Low-alpha remote background haze is removed; original nearby alpha is retained.

This is a generated **animation prototype**, not a production-rigged gait. Back-view thrusts angle to the right; side attacks can rotate the torso into three-quarter view. Walk articulation is limited and some strides have similar leg silhouettes. Red horns, red eyes, closed faceplate, dark plate, crimson cape/tabard, sword-right/shield-left equipment and shield sigil remain recognizable, but details and scale can drift between poses. Do not claim exact reference fidelity or physically correct footfall. Attack FPS/hit events are suggested placeholders, not measured collisions.
