#!/usr/bin/env python3
"""Offline conservative circle-vs-component-box route clearance QA, not a runtime collider."""
from pathlib import Path
import math,json
from generate_meshes import modules
ROOT=Path(__file__).resolve().parent
layout=json.loads((ROOT.parent/'spec/level_layout.json').read_text());templates={m.name:m for m in modules()}
obstacles=[]
for inst in layout['instances']:
 if inst['module_id'] not in ['ruins_wall_2m','ruins_column_4m','ruins_doorway_4m','ruins_rail_2m','ruins_rubble_1m','ruins_statue_plinth_4m','ruins_statue_proxy']:continue
 assert inst['rotation_degrees_xyz'][0]==inst['rotation_degrees_xyz'][2]==0
 assert inst['scale_xyz'][0]==inst['scale_xyz'][2]==1 and inst['scale_xyz'][1]>0
 scale_y=inst['scale_xyz'][1]
 yaw=math.radians(inst['rotation_degrees_xyz'][1]);co,si=math.cos(yaw),math.sin(yaw);p=inst['position_m']
 for c in templates[inst['module_id']].components:
  x,y,z=c['center'];obstacles.append({'id':inst['instance_id'],'center':(p[0]+co*x+si*z,p[1]+y*scale_y,p[2]-si*x+co*z),'size':(c['size'][0],c['size'][1]*scale_y,c['size'][2]),'yaw':yaw+c['yaw']})
cells={tuple(c['cell']):c for c in layout['cells']};radius=layout['player_assumptions']['collision_radius_m'];height=1.75
routes=[]
for name in ['validated_main_route','validated_water_route']:
 route=layout['navigation'][name];collisions=[];ns=0
 assert all(cells[tuple(c)]['walkable'] for c in route)
 legal={frozenset((tuple(e['a']),tuple(e['b']))) for e in layout['navigation']['edges']}
 assert all(frozenset((tuple(a),tuple(b))) in legal for a,b in zip(route,route[1:]))
 for a,b in zip(route,route[1:]):
  aa=(2*a[0]+1,cells[tuple(a)]['surface_y_m'],2*a[1]+1);bb=(2*b[0]+1,cells[tuple(b)]['surface_y_m'],2*b[1]+1)
  for step in range(41):
   t=step/40;x,y,z=[aa[k]*(1-t)+bb[k]*t for k in range(3)];ns+=1
   for o in obstacles:
    cx,cy,cz=o['center'];sx,sy,sz=o['size']
    if y+height<=cy-sy/2 or y+.03>=cy+sy/2:continue
    dx,dz=x-cx,z-cz;co,si=math.cos(o['yaw']),math.sin(o['yaw']);lx=co*dx-si*dz;lz=si*dx+co*dz
    ex=max(abs(lx)-sx/2,0);ez=max(abs(lz)-sz/2,0)
    if ex*ex+ez*ez < radius*radius-1e-9:collisions.append({'instance':o['id'],'at':[round(x,3),round(y,3),round(z,3)],'edge':[a,b]})
 routes.append({'name':name,'sampleSpacingMeters':.05,'samples':ns,'obstacleComponentCount':len(obstacles),'collisionCount':len(collisions),'collisions':collisions[:20]})
report={'status':'pass' if not any(r['collisionCount'] for r in routes) else 'needs_review','method':'Offline 0.28m horizontal player circle with1.75m vertical span sampled every0.05m along two specified cell-center routes, against conservative oriented authoring component boxes. Floors/steps/water excluded from solid obstacles. Height interpolates between declared cells.','limitations':['Not an engine physics test or navmesh.','Not every walkable cell/edge tested.','Does not establish step climbing/ground support or other controller behavior.','Boxes used for QA only; no runtime colliders are supplied.'],'routes':routes}
(ROOT/'layout_clearance_report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
