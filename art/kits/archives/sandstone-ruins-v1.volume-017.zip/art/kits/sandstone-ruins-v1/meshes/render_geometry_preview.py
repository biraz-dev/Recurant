"""Blender 4.3+: independent GLB import smoke test + geometry-only contact sheet.
blender --background --python meshes/render_geometry_preview.py
"""
from pathlib import Path
import bpy,json,math
from mathutils import Vector
ROOT=Path(__file__).resolve().parent
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=48;scene.cycles.use_denoising=False
scene.render.resolution_x=1800;scene.render.resolution_y=1500;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
scene.world.color=(.15,.15,.15)
scene.view_settings.view_transform='Standard';scene.view_settings.look='Medium High Contrast';scene.view_settings.exposure=0;scene.view_settings.gamma=1
manifest=json.loads((ROOT/'mesh_manifest.json').read_text());results=[]
labels={'ruins_floor_2m':'FLOOR / 2 m','ruins_wall_2m':'WALL / 2 x 4 m','ruins_column_4m':'COLUMN / 4 m','ruins_doorway_4m':'DOOR / 3 m CLEAR','ruins_rail_2m':'RAIL / 2 m','ruins_bridge_deck_2m':'BRIDGE / 2 m','ruins_stairs_2m_rise06':'STAIRS / 0.6 m RISE','ruins_rubble_1m':'RUBBLE / ~1 m','ruins_water_2m':'WATER / 2 m','ruins_statue_plinth_4m':'PLINTH / 4 m','ruins_statue_proxy':'STATUE / BLOCKOUT ONLY'}
def mat(name,color):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;n=m.node_tree.nodes.get('Principled BSDF');n.inputs['Base Color'].default_value=(*color,1);n.inputs['Roughness'].default_value=1;return m
labelmat=mat('Preview typography',(.75,.82,.8))
def text(s,loc,size=.25):
 data=bpy.data.curves.new('Label','FONT');data.body=s;data.align_x='CENTER';data.size=size;data.extrude=0
 ob=bpy.data.objects.new('Label',data);scene.collection.objects.link(ob);ob.location=loc;data.materials.append(labelmat)
for index,item in enumerate(manifest['assets']):
 before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(ROOT/item['files']['glb']))
 imported=set(bpy.data.objects)-before;meshes=[o for o in imported if o.type=='MESH']
 ntris=sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in meshes)
 assert ntris==item['triangles'],(item['id'],ntris,item['triangles'])
 assert all(o.data.uv_layers for o in meshes)
 x=(index%4-1.5)*6;y=8-(index//4)*9
 for ob in imported:
  if ob.parent is None:ob.location.x+=x;ob.location.y+=y
 for ob in meshes:
  assert all(math.isfinite(c) for v in ob.data.vertices for c in v.co)
 results.append({'id':item['id'],'blenderImportedTriangles':ntris,'uvLayerPresent':True,'status':'pass'})
 text(labels.get(item['id'],item['id']),(x,y-2.6,.03),.27)
 text(f"{item['triangles']} tris",(x,y-3.2,.03),.22)
text('MODULAR RUINS  /  GEOMETRY BASES',(0,14.4,.03),.65)
text('Untextured kit inspection - not a finished level or statue reconstruction',(0,13.4,.03),.28)
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.26));bpy.context.object.data.materials.append(mat('Backdrop',(.055,.075,.08)))
def area(loc,power,size):
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(Vector((0,0,0))-o.location).to_track_quat('-Z','Y').to_euler()
area((-8,-12,24),8000,20);area((12,6,16),6000,15)
bpy.ops.object.camera_add(location=(0,-32,34));cam=bpy.context.object;cam.rotation_euler=(Vector((0,1,0))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=32;scene.camera=cam
scene.render.filepath='//geometry_contact_sheet.png'
(ROOT/'blender_import_validation.json').write_text(json.dumps({'blenderVersion':bpy.app.version_string,'status':'pass','results':results},indent=2)+'\n')
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'geometry_preview.blend'))
bpy.ops.render.render(write_still=True)
print('GEOMETRY_PREVIEW_COMPLETE')
