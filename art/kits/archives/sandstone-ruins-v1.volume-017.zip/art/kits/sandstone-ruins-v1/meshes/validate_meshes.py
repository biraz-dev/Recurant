#!/usr/bin/env python3
"""Independent parser checks for the exported GLB and OBJ data; no imports of authoring code."""
from pathlib import Path
import json,struct,math,hashlib
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'mesh_manifest.json').read_text());results=[]
for item in manifest['assets']:
 p=ROOT/item['files']['glb'];raw=p.read_bytes();magic,ver,size=struct.unpack_from('<4sII',raw)
 assert magic==b'glTF' and ver==2 and size==len(raw)
 jlen,jtag=struct.unpack_from('<I4s',raw,12);assert jtag==b'JSON'
 d=json.loads(raw[20:20+jlen]);blen,btag=struct.unpack_from('<I4s',raw,20+jlen)
 assert btag==b'BIN\0';binary=raw[28+jlen:];assert blen==len(binary)
 assert d['asset']['version']=='2.0' and len(d['buffers'])==1 and 'uri' not in d['buffers'][0]
 assert not d.get('images') and not d.get('textures') # named placeholders; no missing external files
 def accessor(i):
  a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];offset=v.get('byteOffset',0)+a.get('byteOffset',0)
  typ={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];f,nb={5126:('f',4),5123:('H',2)}[a['componentType']]
  stride=v.get('byteStride',nb*typ);assert offset+a['count']*stride <= v.get('byteOffset',0)+v['byteLength']
  assert v.get('byteOffset',0)+v['byteLength']<=d['buffers'][0]['byteLength']<=len(binary)
  out=[struct.unpack_from('<'+f*typ,binary,offset+n*stride) for n in range(a['count'])]
  assert all(math.isfinite(x) for row in out for x in row)
  return out
 tri_count=0
 for mesh in d['meshes']:
  for pr in mesh['primitives']:
   pos=accessor(pr['attributes']['POSITION']);nor=accessor(pr['attributes']['NORMAL']);uv=accessor(pr['attributes']['TEXCOORD_0']);ind=accessor(pr['indices'])
   assert len(pos)==len(nor)==len(uv) and len(ind)%3==0
   assert all(0<=i[0]<len(pos) for i in ind)
   assert all(abs(sum(x*x for x in n)-1)<1e-5 for n in nor)
   for k in range(3):
    assert abs(min(v[k] for v in pos)-item['bounds']['min'][k])<1e-5
    assert abs(max(v[k] for v in pos)-item['bounds']['max'][k])<1e-5
   for j in range(0,len(ind),3):
    a,b,c=[pos[ind[j+k][0]] for k in range(3)]
    u=[b[k]-a[k] for k in range(3)];v=[c[k]-a[k] for k in range(3)]
    cr=(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])
    assert sum(x*x for x in cr)>1e-14
    assert sum(cr[k]*nor[ind[j][0]][k] for k in range(3))>0
   tri_count+=len(ind)//3
 assert tri_count==item['triangles']<500
 assert d['nodes'][0].get('translation',[0,0,0])==[0,0,0]
 assert d['nodes'][0].get('scale',[1,1,1])==[1,1,1]
 text=(ROOT/item['files']['obj']).read_text().splitlines();v=[l for l in text if l.startswith('v ')];vt=[l for l in text if l.startswith('vt ')];vn=[l for l in text if l.startswith('vn ')];f=[l for l in text if l.startswith('f ')]
 assert len(v)==len(vt)==len(vn)==item['vertices'] and len(f)==item['triangles']
 assert (ROOT/item['files']['mtl']).is_file()
 for line in f:
  tokens=line.split()[1:];assert len(tokens)==3
  for tok in tokens:
   a,b,c=map(int,tok.split('/'));assert 1<=a<=len(v) and 1<=b<=len(vt) and 1<=c<=len(vn)
 results.append({'id':item['id'],'status':'pass','triangles':tri_count,'vertices':len(v),'glbSha256':hashlib.sha256(raw).hexdigest(),'aabb':item['bounds']})
report={'status':'pass','checks':['GLB2 header/chunk sizes','buffer/accessor bounds','finite positions/normals/UV0','unit normals','CCW triangle winding matches normals','nondegenerate triangles','index bounds','AABB matches manifest','identity transform/pivot origin','OBJ v/vt/vn and complete face references','all modules <500triangles','no external image references in GLBs','local MTL exists'],'moduleCount':len(results),'totalTriangles':sum(x['triangles'] for x in results),'results':results}
(ROOT/'validation_report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))
