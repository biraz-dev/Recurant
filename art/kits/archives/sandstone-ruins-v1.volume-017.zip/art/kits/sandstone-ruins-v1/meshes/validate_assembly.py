#!/usr/bin/env python3
"""Independent assembled GLB parser, counts, transforms, AABB and buffer-bound checks."""
from pathlib import Path
import json,math,struct,hashlib,sys
import numpy as np
from generate_meshes import modules
ROOT=Path(__file__).resolve().parent;filename=sys.argv[1] if len(sys.argv)>1 else 'assembled_blockout.glb';raw=(ROOT/filename).read_bytes()
magic,version,length=struct.unpack_from('<4sII',raw);assert (magic,version,length)==(b'glTF',2,len(raw))
jlen=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+jlen]);blen,btag=struct.unpack_from('<I4s',raw,20+jlen);assert btag==b'BIN\0';binary=raw[28+jlen:];assert len(binary)==blen
image_checks=[]
if filename=='assembled_blockout.glb':assert not d.get('images') and not d.get('textures')
for im in d.get('images',[]):
 assert 'uri' not in im and im.get('mimeType')=='image/png'
 v=d['bufferViews'][im['bufferView']];off=v.get('byteOffset',0);payload=binary[off:off+v['byteLength']];assert payload[:8]==b'\x89PNG\r\n\x1a\n';width,height=struct.unpack_from('>II',payload,16);assert (width,height)==(256,256);source=ROOT.parent/'art/runtime/256/materials'/(im['name']+'.png');assert source.is_file() and payload==source.read_bytes();image_checks.append({'name':im.get('name'),'width':width,'height':height,'embedded':True,'byteExactSourceMatch':True,'source':'../art/runtime/256/materials/'+source.name})
for t in d.get('textures',[]):
 assert 0<=t['source']<len(d['images'])
 if 'sampler' in t:assert 0<=t['sampler']<len(d.get('samplers',[]))
for m in d.get('materials',[]):
 tex=m.get('pbrMetallicRoughness',{}).get('baseColorTexture')
 if tex:assert 0<=tex['index']<len(d.get('textures',[]))
def accessor(index):
 a=d['accessors'][index];view=d['bufferViews'][a['bufferView']];nc={'VEC2':2,'VEC3':3,'VEC4':4,'SCALAR':1}[a['type']];fmt,sz={5126:('f',4),5123:('H',2),5125:('I',4)}[a['componentType']];stride=view.get('byteStride',nc*sz);offset=view.get('byteOffset',0)+a.get('byteOffset',0)
 assert offset+(a['count']-1)*stride+nc*sz<=view.get('byteOffset',0)+view['byteLength']<=len(binary)
 x=np.array([struct.unpack_from('<'+fmt*nc,binary,offset+k*stride) for k in range(a['count'])]);assert np.isfinite(x).all();return x
for mesh in d['meshes']:
 for p in mesh['primitives']:
  xyz=accessor(p['attributes']['POSITION']);n=accessor(p['attributes']['NORMAL']);uv=accessor(p['attributes']['TEXCOORD_0']);i=accessor(p['indices']);assert len(xyz)==len(n)==len(uv);assert i.min()>=0 and i.max()<len(xyz) and len(i)%3==0;assert np.allclose((n*n).sum(axis=1),1,atol=1e-5)
def trs(node):
 if 'matrix' in node:return np.array(node['matrix']).reshape((4,4),order='F')
 x,y,z,w=node.get('rotation',[0,0,0,1]);R=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])
 M=np.eye(4);M[:3,:3]=R@np.diag(node.get('scale',[1,1,1]));M[:3,3]=node.get('translation',[0,0,0]);return M
layout=json.loads((ROOT.parent/'spec/level_layout.json').read_text());expected={i['instance_id']:i for i in layout['instances']};templates={m.name:m for m in modules()};world=np.eye(4);checked=0;max_error=0;triangles=0;allpoints=[]
for node in d['nodes']:
 assert node['name'] in expected and 'mesh' in node and not node.get('children')
 item=expected[node['name']];assert node['extras']['module_id']==item['module_id'];assert node['extras']['role']==item['role']
 points=np.concatenate([accessor(p['attributes']['POSITION']) for p in d['meshes'][node['mesh']]['primitives']]);M=trs(node);actual=(M[:3,:3]@points.T).T+M[:3,3]
 angles=np.radians(item['rotation_degrees_xyz']);x,y,z=angles;cx,sx,cy,sy,cz,sz=np.cos(x),np.sin(x),np.cos(y),np.sin(y),np.cos(z),np.sin(z)
 R=np.array([[cz,-sz,0],[sz,cz,0],[0,0,1]])@np.array([[cy,0,sy],[0,1,0],[-sy,0,cy]])@np.array([[1,0,0],[0,cx,-sx],[0,sx,cx]])
 source=np.array(templates[item['module_id']].positions);target=(R@np.diag(item['scale_xyz'])@source.T).T+item['position_m']
 error=max(float(np.max(np.abs(actual.min(axis=0)-target.min(axis=0)))),float(np.max(np.abs(actual.max(axis=0)-target.max(axis=0)))))
 assert error<1e-4,(node['name'],error);max_error=max(max_error,error);checked+=1;allpoints.append(actual)
 triangles+=sum(len(accessor(p['indices']))//3 for p in d['meshes'][node['mesh']]['primitives'])
assert checked==len(expected)==len(d['nodes']);allpoints=np.concatenate(allpoints)
report={'status':'pass','instancesChecked':checked,'meshes':len(d['meshes']),'materials':[m['name'] for m in d['materials']],'instancedTriangles':triangles,'maxAabbErrorMeters':max_error,'worldBounds':{'min':allpoints.min(axis=0).tolist(),'max':allpoints.max(axis=0).tolist()},'checks':['GLB2 headers and chunks','accessor bounds/finite attributes/unit normals','triangle index bounds','266 named instance module and role identities','all exported node world AABBs agree with source module + declared XYZ transform within0.0001m','no external image references'],'file':filename,'embeddedImages':image_checks,'samplers':d.get('samplers',[]),'sha256':hashlib.sha256(raw).hexdigest()}
(ROOT/('textured_assembly_validation_report.json' if filename=='assembled_textured.glb' else 'assembly_validation_report.json')).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
