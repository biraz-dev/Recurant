# Copy paste prompt for Claude

Attach or provide the extracted level-kit directory, then paste the following prompt. If Claude cannot access files, give it the two JSON files and this guide first, then supply the meshes and images through the coding environment. The prompt does not make assets accessible by itself.

---

Implement this supplied ruins environment kit in my existing dungeon game. The intended game is grid based, using Rust/Bevy with a 3D environment and separate 2D billboard enemies, a 320 × 240 internal viewport, browser/Wasm plus Linux/Android handheld targets. A possible later N64 port is a separate effort, not a requirement to make Bevy or these GLBs run on N64 now.

First inspect the repository instructions, actual dependency versions and existing controller/rendering architecture. Do not assume a current Bevy API or replace working systems unnecessarily. Do not fetch third-party assets, publish anything, or create a new game project unless I ask.

Read, in order:
1. `spec/INTEGRATION_GUIDE.md`
2. `spec/module_catalog.json`
3. `spec/level_layout.json`
4. `meshes/mesh_manifest.json`

View `reference/source_concept.png`, `spec/topdown_plan.svg`, `spec/module_dimensions.svg`, and the art style guide if present. The source establishes a warm sandstone ruin with square columns, moss/vines, shaded corridors, bright water courts and a seated statue. The layout and dimensions are proposed, not an exact reconstruction. The SVG diagrams and JSON—not the AI orthographic image—govern measurements.

Use the eleven supplied `meshes/ruins_*.glb` modules, with OBJ/MTL as alternatives. For an immediate visual bootstrap, `meshes/assembled_textured.glb` embeds the runtime textures and full layout; `meshes/assembled_blockout.glb` is its flat-color counterpart. Choose one assembled scene OR module instancing, never both. Navigation and collision still come from the spec. Preserve units and pivots: meters, +Y up, −Z forward, +X right, 2 m grid. Cell centers are `[2*x+1, surfaceY, 2*z+1]`. Floor/bridge pivots are at their top surface; most other pivots are base-center. Stairs have an asymmetric LOW-edge pivot, local Z −2…0, and ascend −Z. Use the explicit transforms in `level_layout.json`; do not silently re-center models. Ceiling instances reuse floor meshes rotated X=180° at Y=4 m.

The layout has a shaded corridor, junction, 4 m-wide bridge, shallow-water alternative with two stairs, and statue chamber. Dry ground is Y=0; pool bed −0.6; water −0.3. Start at cell `[2,17]` facing north; proposed goal `[13,8]` faces the statue. The statue is a blockout placeholder, not finished hero art.

Implement the explicit cardinal navigation edges, not just movement between every adjacent floor cell. Missing edges are forbidden. The northern pool is scenic/non-traversable; the southern water route is the playable alternative. Use the catalog's collision proposals: compound doorway boxes leave the 3 × 3 m opening clear; stairs use smooth ramp collision; water has no collider; plinth cells are blocked. Never use one full doorway bounds collider. Preserve the east-west-only stair traversal of the grid design. Do not add diagonal movement or jumping implicitly. Run both validated routes from the JSON.

Bind material names to these basecolor candidates:
- `M_Sandstone` → `art/runtime/256/materials/sandstone_blocks_basecolor.png`
- `M_Floor` → `art/runtime/256/materials/worn_floor_basecolor.png`
- `M_Carved` → `art/runtime/256/materials/sandstone_blocks_basecolor.png` initially
- `M_Rubble` → `art/runtime/256/materials/rubble_stone_basecolor.png`
- `M_Water` → `art/runtime/256/materials/water_basecolor.png`

**Carved trim exception:** the original carved texture is a motif sheet, not a whole-image tile. Keep the safe sandstone fallback on `M_Carved` until you create explicit UV selections or strip UVs. Optional `art/runtime/256/trim/carved_meander_strip.png` and `carved_diamond_strip.png` are U-repeat candidates with V clamped; do not apply them blindly to generic planar UVs.

The mesh UV0 scale is nominally one repeat per 2 m. Test a 3 × 3 texture repeat; generated tileability and alpha edges need QA. No normal/roughness/displacement maps are supplied. Start with basecolor, high roughness, a small shared material set and opaque water. Keep original images untouched. Optional moss/dirt variants and foliage RGBA images can be added after base traversal works. Foliage card geometry still needs creation; use a few alpha-mask cards without collision, not layers of blended transparency.

Work in checkpoints:
1. Flat-color loading, layout and debug navigation.
2. Collision and camera traversal through both routes.
3. Five core textures and restrained lighting.
4. Modest vegetation and 320 × 240 readability pass.
5. Release/native and Wasm tests, plus measured performance where hardware is available.

Do not invent enemy art, audio, finished character systems or a complete-game claim. Keep billboard enemy integration separate from this environment task. Proposed budgets are 30 fps at 320 × 240, about 20,000 visible triangles and about 40 visible draw submissions after batching/culling; they are targets, not guarantees. The full current layout is 39,336 triangles before culling. Profile rather than assuming every instance is cheap.

At each checkpoint report what actually works, changed files, tests run, failed tests, and missing inputs. If an asset is absent, name its exact path and use an explicitly labeled placeholder instead of silently substituting unrelated art. Finish with the controls, how to launch the level, both route test results, measured or unverified target performance, and any remaining visual/integration limitations.
