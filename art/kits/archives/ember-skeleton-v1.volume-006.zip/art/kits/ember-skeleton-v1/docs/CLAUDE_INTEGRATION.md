# Claude integration guide — Ember skeleton (134)

## Objective

Import the supplied ember skeleton so it can move in a 2D game world and play four directional walk and attack animations. Reuse the supplied pixels: do not redraw the character, hallucinate extra frames, cut the raw source sheets into uniform cells, or mirror one side to replace the other. The reference is a charred bare skeleton with glowing coal inside its bones and ribs, no flesh, clothing, armor or weapons.

The manifest schema is shared with the earlier character kit. Its schema identifier is retained for compatibility; `asset: "ember_skeleton"` identifies this character. Asset path values (`native`, `master`, `runtime`, `atlas128`, `atlas256`) inside `frames/manifest.json` are relative to that manifest's containing directory. The `source` value is a provenance filename located in `art/originals/`, not a runtime asset path.

## Asset contract

Prefer **one** of these two import routes:

- Atlas route: load `frames/atlases128/{front,back,left,right}.png`. Each image is 768 × 512, arranged as six columns × four rows of exact 128 × 128 tiles. Use manifest `rect128` values, with no trimming or additional spacing.
- Individual route: load `frames/frames128/{view}_{action}_{00..05}.png` in manifest order.

For a larger sprite or high-resolution camera, use the corresponding 256px assets/rectangles. For original cutout detail, use `native` paths and the crop-specific `native_pivot` from each frame record. Do not center variable-size native crops by their bounding boxes.

| View | Facing in a conventional screen-Y-down game |
|---|---|
| `front` | Down / toward the camera |
| `back` | Up / away from the camera |
| `left` | Screen left |
| `right` | Screen right |

These are four orthographic-style directions, not eight directions. With diagonal movement, choose the dominant absolute movement axis; retain the previous facing on an exact tie to avoid flicker. Remap vectors if the engine uses different world coordinates.

## Ground anchor and scale

- 128px frame origin: **(64, 116)**.
- 256px frame origin: **(128, 232)**.
- Normalized origin: **(0.5, 0.90625)**.

Place that origin at the entity's ground position. If an engine expects a bottom-left origin, convert the Y coordinate accordingly rather than copying the number blindly. The provided pixel values use image coordinates from the top-left.

All frames were resized with a **single global source-to-master scale of 0.505**, never individually stretched to fill a tile. Most upright bodies are around 120–130px tall in the 256px canvas (about 60–65px in runtime frames); padding intentionally accommodates extended claws and lunge reach. Set one world/render scale for the character. Do not normalize each frame's visible height or recenter its head.

The anchor is a repeatable image-analysis heuristic: the alpha-weighted horizontal center of the lowest 30% of the major body, with retained alpha bottom aligned to the ground baseline. It is not a rigged pelvis joint and does not promise zero foot sliding.

## Animations

The six source frames are indexed **0 through 5**. Rows and actions:

| Atlas row | Action | FPS | Loop in gameplay | Proposed zero-based hit frame |
|---:|---|---:|---|---:|
| 0 | `walk` | 8 | Yes | None |
| 1 | `claw_swipe` | 10 | No | 3 |
| 2 | `lunge` | 10 | No | 3 |
| 3 | `two_hand_slam` | 8 | No | 4 |

Animation keys are `{view}_{action}`, for example `left_claw_swipe`. Obtain each ordered frame-name list from `manifest.animations[key].frames`; obtain file paths/atlas coordinates from `manifest.frames[frameName]`.

Movement and animation are separate. Advance the entity using velocity, navigation and collision; playing the walk frames does not move it. Select the view from the movement/facing vector and advance the walk cycle only while moving. On stopping, freeze `walk` frame 0 as a simple idle fallback; this is a reused pose, not a new idle animation.

On attack:

1. Lock the selected facing until the attack finishes.
2. Start the chosen action at frame 0, play once, and block unintended animation restarts each update.
3. Fire the attack event once when elapsed animation time crosses its chosen hit-frame boundary, including when a slow update skips over that frame. Do not fire every tick while the hit frame is visible.
4. Use a gameplay hit area derived from facing, range and the design's collision rules. Do not use opaque sprite pixels as collision geometry.
5. Return to the current-direction walk if moving, or the idle fallback if stationary. Manifest `return_to: "walk"` is an action-family hint, not the name of a full directional animation.

The lunge is an in-place visual sequence. Add a short movement impulse only if the game's combat design calls for one, with collision checks; no measured root-motion displacement is supplied. Slam impact position, hitbox sizes, damage, cooldowns and sound/VFX cues are not authored here. The listed hit frames are suggested starting values and need playtesting.

All preview GIFs repeat for inspection, **including non-looping attacks**. Do not copy the GIF loop behavior into gameplay.

## Rendering

PNG files contain real transparent alpha; keep it enabled. Use ordinary alpha blending for the character. Orange embers are already baked into the pixels; avoid whole-sprite additive blending, which washes out bones. Optional engine lighting/VFX should be separate. Do not color-key black or burn in a checkerboard background.

Nearest-neighbor sampling is a reasonable first setting for the pixel-art look. Check at the actual camera scale; the downscaled assets have antialiased translucent edges. Avoid automatic mipmap/texture bleeding across atlas cells; use the engine's sprite/2D import settings and supplied exact rectangles. Any filtering or pixel-snap choice should be evaluated in the target engine, not assumed universally correct.

## Acceptance checks in the game

- Switching facing does not jump the entity's ground anchor.
- All four walk sequences play in order while moving; stopped entities do not keep walking.
- Claw, lunge and slam all complete once before returning to walk/idle.
- Each attack emits at most one gameplay hit event, including low-FPS updates.
- Extended claws remain visible; no cell-edge cropping or neighboring sprites appear.
- Left/right views are imported separately; no incorrect horizontal mirroring is applied.
- Character silhouette remains the skeleton from `134.png`, distinct from the previous undead kit.

## QA scope and honest limits

The kit has 96 unique saved master-frame images, 96 runtime frames, 96 native cutouts, 16 animation definitions and eight exact-tile atlases. All 192 master/runtime frames are RGBA with transparent margins. No master touches its canvas edge; the minimum margins over all frames are left 32px, top 92px, right 13px and bottom 24px. Every atlas tile is byte-identical to its standalone PNG. Each source has 24 separate major body components and no strong-alpha character pixels at the source canvas edge.

The extraction uses alpha > 32 to identify bodies, attaches nearby visible details within 14 source pixels, and retains original transparency in a four-pixel fringe. Remote faint haze is excluded. This is **not** a per-cell crop: limbs can extend beyond nominal source cells, and complete connected bodies are retained. The left sheet was regenerated once to improve repeated walking silhouettes; both originals are preserved.

These checks establish import consistency, not animation perfection. This is a generated prototype set: some side attacks turn the torso toward three-quarter view, gait and anatomy can drift between drawings, and walking can read as a shuffle. It has not been validated in your engine or playtested. For production use, review timing and silhouettes at game scale and hand-polish motion as needed. Do not claim rig accuracy or production readiness based on file-level checks.
