#!/usr/bin/env python3
"""Validate royal mummy package completeness; no artwork modification."""
from pathlib import Path
from PIL import Image
import json, hashlib

root=Path(__file__).resolve().parents[1]
out=root/'extracted'
manifest=json.loads((out/'manifest.json').read_text())
assert manifest['asset']=='royal_mummy'
assert len(manifest['frames'])==96
assert len(manifest['animations'])==16
counts={k:len(list((out/k).glob('*.png'))) for k in ['frames256','frames128','atlases256','atlases128']}
assert counts=={'frames256':96,'frames128':96,'atlases256':4,'atlases128':4}
assert len(list((out/'native').glob('*/*/*.png')))==96
for name,meta in manifest['frames'].items():
 for field in ['native','master','runtime','atlas256','atlas128','source']:
  path=Path(meta[field]);assert not path.is_absolute(),(name,field)
  assert (out/path).is_file(),(name,field,path)
 for size,field in [(256,'master'),(128,'runtime')]:
  im=Image.open(out/meta[field]);assert im.mode=='RGBA' and im.size==(size,size)
  assert im.getchannel('A').getextrema()[0]==0
  box=im.getchannel('A').getbbox();assert box and box[0]>0 and box[1]>0 and box[2]<size and box[3]<size
  atlas=Image.open(out/meta[f'atlas{size}'])
  x,y,w,h=meta[f'rect{size}'];assert atlas.crop((x,y,x+w,y+h)).tobytes()==im.tobytes()
assert (out/manifest['reference']).is_file()
gifs={}
for path in sorted((out/'previews').glob('*.gif')):
 im=Image.open(path);assert im.n_frames==6
 timings=[]
 for i in range(im.n_frames):im.seek(i);timings.append(im.info['duration'])
 gifs[path.name]={'frames':im.n_frames,'dimensions':list(im.size),'durations_ms':timings}
assert len(gifs)==18
qa={'status':'pass_with_documented_prototype_limitations','asset':'royal_mummy','reference':'sources/reference.png','counts':{**counts,'native_cutouts':96,'animations':16,'gifs':18},'all_relative_manifest_asset_paths_resolve':True,'all_192_atlas_tiles_byte_identical':True,'all_frames_rgba_with_transparent_pixels':True,'no_output_frame_touches_canvas_edge':True,'global_scale':manifest['global_source_to_master_scale'],'master_pivot':manifest['pivot_pixels_master'],'visual_review':{'scope':'All 96 extracted poses and selected silhouettes composited on light background; source pose sheets inspected.','rear_is_rear_facing':True,'side_attack_heads_face_intended_direction':True,'obvious_extra_limbs_observed':False,'clipped_bandage_silhouettes_observed':False,'limitations':['Frame-to-frame linen, jewelry and body-proportion variation.','Some side attack torsos rotate toward three-quarter view.','Generated walk poses are not rigged or physically verified; foot sliding and transition pops may remain.','Impact frames are proposed gameplay markers, not authoritative contacts.']},'gifs':gifs}
(root/'QA.json').write_text(json.dumps(qa,indent=2)+'\n')
files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file() and p.name!='CHECKSUMS.sha256'}
(root/'CHECKSUMS.sha256').write_text(''.join(f'{sha}  {name}\n' for name,sha in files.items()))
print(json.dumps({k:v for k,v in qa.items() if k not in ['gifs','visual_review']},indent=2))
