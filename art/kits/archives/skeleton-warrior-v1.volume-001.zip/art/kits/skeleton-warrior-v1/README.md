# Skeleton warrior animation prototype

Reference: `reference/140.png`. Generated with built-in imagegen, then mechanically isolated/resized with user-approved Python processing.

- 96 generated frames: 4 views × 4 actions × 6 frames.
- `frames256/`: 256×256 RGBA masters; `frames128/`: 128×128 runtime frames.
- `atlases256/`, `atlases128/`: one 6-column × 4-row atlas per direction. Rows: walk, sword_slash, thrust, shield_bash.
- Ground pivot: (128,232) master, (64,116) runtime; normalized (0.5,0.90625).
- `manifest.json`: every filename, rectangle, duration, FPS and suggested zero-based hit frame. Walk loops; attacks return to walk.
- `previews/`: 16 individual action GIFs, two four-view GIFs and contact sheets. Previews alone have opaque backgrounds/labels.
- `native/`: isolated native-resolution frames. `art/`: raw sheets, prompt set, extraction script and segmentation report.

## QA and limitations
24 separate connected body components were found per sheet, with no strong-alpha source-edge contact. All 192 master/runtime atlas tiles exactly match standalone PNGs. No output frame touches an edge. Segmentation follows each complete component even where weapons cross nominal cell boundaries, rather than blind grid cropping. Low-alpha remote background haze is removed; original nearby alpha is retained.

This is a generated **animation prototype**, not a production-rigged gait. Front/back thrusts angle sideways rather than remaining on the depth axis; side attacks can rotate the torso into three-quarter view. Front/back walk articulation is limited; side walk poses visibly show contact, heel-lift and passing stages, but are not a verified physical gait. Bare skull, exposed ivory bones, slate-blue cloth, rusted brown guards, sword-right/shield-left equipment and round blue shield remain recognizable. Cloth tails sometimes broaden, armour and bone proportions drift between poses, and shield surfaces were repaired with imagegen. Do not claim exact reference fidelity or physically correct footfall. Attack FPS/hit events are suggested placeholders, not measured collisions.

### Source selection
Back v1 rejected for showing outer shield faces from behind. Back v2 rejected for duplicated shields/arms in some poses. Back v3 selected: targeted imagegen edit of v1 corrected the shield inner surface without redesigning the body poses. Both rejected raw variants are retained for provenance only and never included in the frame atlases.
