# Skeleton knight animation prototype

Reference: `reference/136.png`. Generated with built-in imagegen, then mechanically isolated/resized with user-approved Python processing.

- 96 generated frames: 4 views × 4 actions × 6 frames.
- `frames256/`: 256×256 RGBA masters; `frames128/`: 128×128 runtime frames.
- `atlases256/`, `atlases128/`: one 6-column × 4-row atlas per direction. Rows: walk, sword_slash, thrust, shield_bash.
- Ground pivot: (128,232) master, (64,116) runtime; normalized (0.5,0.90625).
- `manifest.json`: every filename, rectangle, duration, FPS and suggested zero-based hit frame. Walk loops; attacks return to walk.
- `previews/`: 16 individual action GIFs, two four-view GIFs and contact sheets. Previews alone have opaque backgrounds/labels.
- `native/`: isolated native-resolution frames. `art/`: raw sheets, prompt set, extraction script and segmentation report.

## QA and limitations
24 separate connected body components were found per sheet, with no strong-alpha source-edge contact. All 192 master/runtime atlas tiles exactly match standalone PNGs. No output frame touches an edge. Segmentation follows each complete component even where weapons cross nominal cell boundaries, rather than blind grid cropping. Low-alpha remote background haze is removed; original nearby alpha is retained.

This is a generated **animation prototype**, not a production-rigged gait. Front/back thrusts angle sideways rather than remaining on the depth axis; side attacks can rotate the torso into three-quarter view. Front/back walk articulation is limited; side walk poses visibly show contact, heel-lift and passing stages, but are not a verified physical gait. Skull face, pointed ridged helmet, steel/bronze plate, crimson cloak/tabard, sword-right/shield-left equipment and shield cross remain recognizable, but armour details and proportions can drift between poses. Do not claim exact reference fidelity or physically correct footfall. Attack FPS/hit events are suggested placeholders, not measured collisions.
