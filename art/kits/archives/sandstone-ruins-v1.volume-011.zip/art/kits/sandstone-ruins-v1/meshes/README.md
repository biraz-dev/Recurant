# Modular ruins geometry — handoff notes

**Authored low-poly bases inspired by `../reference/source_concept.png`, not an exact reconstruction.** The statue is an abstract seated blockout, not a finished sculpt or a historical/cultural reconstruction.

## Start here

- `assembled_textured.glb`: optional ready scene, 266 placements / 11 shared meshes, with embedded 256 px basecolor candidates. No missing external image links. This is static art, **not a playable game**.
- `assembled_blockout.glb`: same proposed scene with five named solid-color material slots, for an untextured baseline.
- `ruins_*.glb`: the 11 independent modules; each includes normals, UV0 and named flat-color materials.
- `ruins_*.obj` + matching `.mtl`: interchange alternatives with explicit `v/vt/vn` triangle faces. Keep each MTL beside its OBJ.
- `mesh_manifest.json`: exact per-module bounds, pivot, dimensions, materials and counts.
- `MATERIAL_BINDINGS.json`: verified optional runtime texture paths and sampler guidance.
- `../spec/level_layout.json`: authoritative proposed instance placement and route data. The scene GLBs are built from this file.
- `*_preview.png`: geometry/material inspection renders, not target-quality screenshots. Corridor ceilings are hidden in the overview PNGs **only**; the GLBs include them.
- Offline authoring/assembly scripts are included for reproducibility. Preview-only Blender work files are not required or included; import the GLBs into a DCC to edit directly. The scripts can also regenerate local Blender inspection scenes.

## Coordinate and placement contract

All meshes use metres, right-handed +Y up, local -Z forward, +X right. The planning grid is 2 m. Origin is the declared pivot; GLB module transforms are identity. Mesh normals face outward with counter-clockwise triangles. Do not apply a second Y-up conversion when the importing engine already handles glTF.

| Module | Actual AABB size X × Y × Z (m) | Origin / pivot | Triangles |
|---|---:|---|---:|
| `ruins_floor_2m` | 2 × 0.2 × 2 | top center | 176 |
| `ruins_wall_2m` | 2 × 4 × 0.4 | base center | 176 |
| `ruins_column_4m` | 1 × 4 × 1 | base center | 132 |
| `ruins_doorway_4m` | 4 × 4 × 1 | base center | 308 |
| `ruins_rail_2m` | 2 × 0.6 × 0.3 | base center | 44 |
| `ruins_bridge_deck_2m` | 2 × 0.4 × 2 | top center | 176 |
| `ruins_stairs_2m_rise06` | 2 × 0.6 × 2 | bottom front center | 36 |
| `ruins_rubble_1m` | 1.08386 × 0.675 × 0.962393 | base center | 176 |
| `ruins_water_2m` | 2 × 0 × 2 | surface center | 2 |
| `ruins_statue_plinth_4m` | 4 × 0.4 × 4 | base center | 88 |
| `ruins_statue_proxy` | 2 × 3.6 × 1.9 | base center | 440 |

Floor and bridge top faces are at Y=0; their thickness extends below. Water is a zero-thickness plane at Y=0, double-sided and alpha blended. The 2 m stair has local extents X=-1..1, Y=0..0.6, Z=-2..0; its origin is the **bottom front edge center**, not the footprint center. It rises toward -Z in three 0.2 m risers. Stair climbing must be implemented/tested by the game controller.

The doorway is 4 m wide and 4 m high, with a conservative 3 m wide by 3 m high clear opening. Its component bevels do not shrink that opening. For a ceiling tile, reuse a floor tile rotated 180° about X: underside stays at its local Y=0 and thickness extends upward.

The assembled scene scales columns by Y=1.025 so their capitals end at 4.1 m, avoiding coplanar overlap with the 4 m walls. Individual column geometry remains 4 m high. Each column base stays at floor height. Perpendicular boundary walls use Y=0.9995 scaling (a 2 mm top-height difference on a 4 m wall) to remove coplanar corner-top overlap; the exact transforms are in the layout JSON.

## Materials and texture projection

UV0 is face-planar at **one texture repeat per 2 m**; UV seams at hard edges/chamfers are intentional. This is not a packed lightmap atlas. Floor slab UVs follow their placement within the module. Unit materials are deliberately untextured; binding textures is optional.

Use the verified 256×256 RGB maps in `../art/runtime/256/materials/` as sRGB basecolor, nearest filtering (the textured GLB uses nearest texels with nearest mip selection), repeat U/V for candidate tiling surfaces. On bind, set basecolor RGB multiplier to white; otherwise the placeholder tint will darken the image. Retain water's 0.7 alpha if using the suggested static look. The optional textured scene embeds these exact maps. Generated basecolors can contain painted lighting; they are not certified seamless or physically calibrated albedo.

`M_Carved` safely uses the **sandstone** texture in the textured scene. The carved image is a motif sheet, not a whole-sheet repeatable tile. To use the carved designs, author dedicated face UVs or use the art folder's U-repeat/V-clamp trim strips; do not blindly tile the entire motif sheet on every face.

No normal, metallic, roughness, AO or displacement image maps are supplied by this mesh pack. Roughness is a material constant (0.9–1 for stone; 0.22 for stylized water); metallic is zero. Water has no wave, reflection or refraction simulation. Foliage art is separate: there are no foliage meshes in this bounded module set.

## What is and is not verified

- 11 modules: **1,754 triangles total**, maximum **440 triangles** on the statue proxy.
- Complete scene: **266 instances, 11 shared meshes, 39,336 instanced triangles**.
- Independent exported-file checks verify GLB 2 headers, chunk/buffer/accessor bounds, finite attributes, unit normals, explicit UV0, triangle winding/index bounds, exact module AABBs, identity pivots, and matching OBJ/MTL references.
- Blender 4.3.2 independently imported all 11 GLBs and checked counts/UV layers; rendered previews were visually reviewed. Visual review corrected column/wall coplanarity and statue leg coplanarity.
- The exported assembly's 266 node world bounds are compared against the JSON XYZ transforms and source meshes, tolerance 0.0001 m.
- Both nominated routes pass conservative offline player-circle clearance samples (radius 0.28 m, height 1.75 m, every 0.05 m) against solid obstacle component boxes. See `layout_clearance_report.json` for limits.

**No runtime engine import, physics, step-climbing, occlusion, lighting bake, gameplay or performance certification.** No collision meshes, rigid bodies, navmesh, UV1/lightmap charts, LODs, rigs, animation or tangent streams are included. Triangle geometry contains separate intersecting/abutting authored stone components, not a boolean-unioned watertight solid; do not treat it as collision without deliberate collision authoring. Numerical AABBs and diagnostic component boxes are validation information, not supplied runtime colliders.

## Rebuild locally (optional)

No dependency download is required for module authoring/validation. Use Python 3 for `generate_meshes.py`, `validate_meshes.py`, and `validate_layout_clearance.py`. `validate_assembly.py` also uses NumPy. Use installed Blender 4.3.2+ in background mode for `assemble_level.py` and `render_geometry_preview.py`. These are offline art-authoring helpers, not game-engine code.

```sh
python meshes/generate_meshes.py
python meshes/validate_meshes.py
python meshes/validate_layout_clearance.py
blender --background --python meshes/assemble_level.py
python meshes/validate_assembly.py
python meshes/validate_assembly.py assembled_textured.glb
blender --background --python meshes/render_geometry_preview.py
```
