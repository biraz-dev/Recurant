"""Blender-only scene assembly from spec/level_layout.json; no game-engine code.
blender --background --python meshes/assemble_level.py
Exports a geometry-only GLB with the exact declared instance transforms and a cutaway preview.
"""
from pathlib import Path
import bpy,json,math,hashlib
from mathutils import Vector,Matrix,Euler
ROOT=Path(__file__).resolve().parent
layoutpath=ROOT.parent/'spec/level_layout.json';layout=json.loads(layoutpath.read_text())
manifest=json.loads((ROOT/'mesh_manifest.json').read_text());lookup={a['id']:a for a in manifest['assets']}
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene;template={};C=Matrix.Rotation(math.pi/2,4,'X');Ci=C.inverted()
for a in manifest['assets']:
 before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(ROOT/a['files']['glb']))
 imported=set(bpy.data.objects)-before;meshes=[o for o in imported if o.type=='MESH'];assert len(meshes)==1
 ob=meshes[0];data=ob.data.copy();data.transform(ob.matrix_world);template[a['id']]=data
 for ob in imported:bpy.data.objects.remove(ob,do_unlink=True)
# Normalize duplicate import materials back to the five documented slot names.
canonical={}
for data in template.values():
 for k,m in enumerate(data.materials):
  base=m.name.split('.')[0]
  if base not in canonical:canonical[base]=m
  data.materials[k]=canonical[base]
instances=[];seen=set()
for item in layout['instances']:
 module=item['module_id'];assert module in template
 key=(module,tuple(item['position_m']),tuple(item['rotation_degrees_xyz']),tuple(item['scale_xyz']));assert key not in seen,('duplicate exact transform',item['instance_id']);seen.add(key)
 ob=bpy.data.objects.new(item['instance_id'],template[module]);scene.collection.objects.link(ob)
 T=Matrix.Translation(Vector(item['position_m']));R=Euler([math.radians(x) for x in item['rotation_degrees_xyz']],'XYZ').to_matrix().to_4x4();S=Matrix.Diagonal(Vector([*item['scale_xyz'],1]))
 ob.matrix_world=C@T@R@S@Ci
 ob['module_id']=module;ob['role']=item['role'];ob['source']='spec/level_layout.json';ob['status']='proposed-layout modular blockout, not exact reference reconstruction'
 instances.append(ob)
# Blender's import/export Y-up conversion is validated via exported transform AABBs separately.
bpy.ops.object.select_all(action='DESELECT')
for ob in instances:ob.select_set(True)
bpy.context.view_layer.objects.active=instances[0]
bpy.ops.export_scene.gltf(filepath=str(ROOT/'assembled_blockout.glb'),export_format='GLB',use_selection=True,export_extras=True,export_cameras=False,export_lights=False,export_yup=True,export_normals=True,export_texcoords=True,export_materials='EXPORT')
report={'status':'pass','instanceCount':len(instances),'walkableCells':sum(1 for c in layout['cells'] if c['walkable']),'navigationEdges':len(layout['navigation']['edges']),'uniqueTransforms':len(seen),'instancedTriangles':sum(lookup[i['module_id']]['triangles'] for i in layout['instances']),'moduleCount':len(set(i['module_id'] for i in layout['instances'])),'layoutSha256':hashlib.sha256(layoutpath.read_bytes()).hexdigest(),'previewNote':'Untextured proposed blockout. Corridor ceiling hidden in PNG only; GLB includes the complete declared layout. Camera/lighting/backdrop are preview-only.'}
(ROOT/'assembly_report.json').write_text(json.dumps(report,indent=2)+'\n')
# Cutaway overview: roof is hidden only for the preview; source layout and exported GLB stay complete.
for ob in instances:
 if ob.get('role')=='ceiling':ob.hide_render=True
scene.render.engine='CYCLES';scene.cycles.samples=40;scene.cycles.use_denoising=False
scene.render.resolution_x=1700;scene.render.resolution_y=1300;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.world.color=(.16,.16,.16)
scene.view_settings.view_transform='Standard';scene.view_settings.look='Medium High Contrast';scene.view_settings.exposure=0
m=bpy.data.materials.new('Preview background only');m.diffuse_color=(.06,.08,.08,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.06,.08,.08,1);p.inputs['Roughness'].default_value=1
bpy.ops.mesh.primitive_plane_add(size=200,location=(18,-20,-.85));bpy.context.object.data.materials.append(m)
def area(loc,power,size):
 bpy.ops.object.light_add(type='AREA',location=loc);ob=bpy.context.object;ob.data.energy=power;ob.data.shape='DISK';ob.data.size=size;ob.rotation_euler=(Vector((18,-20,0))-ob.location).to_track_quat('-Z','Y').to_euler()
area((5,-30,38),17000,28);area((36,-5,25),10000,18)
bpy.ops.object.camera_add(location=(55,-64,52));cam=bpy.context.object;cam.rotation_euler=(Vector((18,-23,0))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=51;scene.camera=cam
scene.render.filepath='//assembled_blockout_preview.png'
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'assembled_blockout_preview.blend'));bpy.ops.render.render(write_still=True)
# Optional textured variant: same exact geometry, embedded real 256px RGB basecolors.
bindings=json.loads((ROOT/'MATERIAL_BINDINGS.json').read_text())['materials']
for name,material in canonical.items():
 path=(ROOT/bindings[name]['texture']).resolve();assert path.is_file(),path
 material.use_nodes=True;nodes=material.node_tree.nodes;bsdf=nodes.get('Principled BSDF');tex=nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(path),check_existing=True);tex.image.colorspace_settings.name='sRGB';tex.image.pack();tex.image.filepath='//../art/runtime/256/materials/'+path.name;tex.interpolation='Closest';tex.extension='REPEAT'
 bsdf.inputs['Base Color'].default_value=(1,1,1,1);material.node_tree.links.new(tex.outputs['Color'],bsdf.inputs['Base Color'])
 material['texture_status']='Generated low-resolution basecolor candidate; not certified seamless; no normal or roughness image maps.'
bpy.ops.object.select_all(action='DESELECT')
for ob in instances:ob.hide_render=False;ob.select_set(True)
bpy.context.view_layer.objects.active=instances[0]
bpy.ops.export_scene.gltf(filepath=str(ROOT/'assembled_textured.glb'),export_format='GLB',use_selection=True,export_extras=True,export_cameras=False,export_lights=False,export_yup=True,export_normals=True,export_texcoords=True,export_materials='EXPORT',export_image_format='AUTO')
for ob in instances:
 if ob.get('role')=='ceiling':ob.hide_render=True
scene.render.filepath='//assembled_textured_preview.png'
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'assembled_textured_preview.blend'));bpy.ops.render.render(write_still=True)
print('ASSEMBLED_BLOCKOUT_AND_TEXTURED_COMPLETE')
