"""Reproducible, authorized crop/resize-only derivatives and non-destructive QA.

Run from any directory: python art/prepare_runtime.py
Original AI-generated masters are never modified. Pillow + numpy required.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json
import hashlib
import numpy as np

ROOT = Path(__file__).resolve().parent
RUNTIME = ROOT / 'runtime' / '256'
QA = ROOT / 'qa'
QA.mkdir(parents=True, exist_ok=True)
records = []
mat_names = ['sandstone_blocks_basecolor', 'worn_floor_basecolor', 'mossy_stone_basecolor', 'compact_dirt_basecolor', 'rubble_stone_basecolor', 'water_basecolor', 'carved_trim_basecolor']
leaf_names = ['fern_cluster_rgba', 'hanging_vines_rgba']
font_path='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
font = ImageFont.truetype(font_path, 15)
small = ImageFont.truetype(font_path, 12)

def rel(p): return p.relative_to(ROOT.parent).as_posix()
def checksum(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def checker(size):
    im=Image.new('RGB',size,(47,48,43));d=ImageDraw.Draw(im)
    for y in range(0,size[1],16):
        for x in range(0,size[0],16):
            if ((x//16)+(y//16))%2: d.rectangle((x,y,x+15,y+15),fill=(61,62,56))
    return im

for folder,names in [('materials',mat_names),('foliage',leaf_names)]:
    (RUNTIME/folder).mkdir(parents=True,exist_ok=True)
    for name in names:
        src=ROOT/folder/(name+'.png');im=Image.open(src)
        out=RUNTIME/folder/src.name
        im.resize((256,256),Image.Resampling.NEAREST).save(out)
        rec={'id':name,'master':rel(src),'runtime_256':rel(out),'master_size':list(im.size),'runtime_size':[256,256],'mode':im.mode,'color_space':'sRGB','nearest_sampling':True,'master_sha256':checksum(src),'runtime_sha256':checksum(out),'generated_by':'image_gen.imagegen','runtime_operation':'nearest-neighbor resize only','seamless_certified':False}
        if folder=='materials':
            a=np.asarray(Image.open(out)).astype(float)
            rec['map_type']='stylized base color only; no physical normal, roughness, metallic or height map'
            rec['edge_mad_rgb_0_to_255']={'horizontal':round(float(abs(a[:,0]-a[:,-1]).mean()),3),'vertical':round(float(abs(a[0]-a[-1]).mean()),3)}
            rec['wrap_policy']='Horizontal strip use only; see extracted strips' if name=='carved_trim_basecolor' else 'Repeat candidate: inspect seams in-engine before long tiled surfaces'
        else:
            a=np.asarray(im.getchannel('A'))
            rec['alpha_extrema']=[int(a.min()),int(a.max())]
            rec['fully_transparent_fraction']=round(float((a==0).mean()),6)
            rec['opaque_threshold_border_pixels']=int((a[0]>=128).sum()+(a[-1]>=128).sum()+(a[:,0]>=128).sum()+(a[:,-1]>=128).sum())
            rec['wrap_policy']='Clamp to edge; alpha test 0.5; double-sided card; no shadow plane'
            rec['origin_hint']='bottom center, adjust mesh card to visible plant base' if name.startswith('fern') else 'top center, adjust mesh card to vine stem start'
        records.append(rec)

# Explicit semantic trims, not a claim that generated master bands have equal heights.
# Pixel rectangles are [left, top, right-exclusive, bottom-exclusive].
trims=[('carved_meander_strip',(0,400,1254,635)),('carved_diamond_strip',(0,690,1254,885))]
src=ROOT/'materials'/'carved_trim_basecolor.png';im=Image.open(src)
(RUNTIME/'trim').mkdir(parents=True,exist_ok=True)
for name,box in trims:
    out=RUNTIME/'trim'/(name+'.png')
    im.crop(box).resize((256,64),Image.Resampling.NEAREST).save(out)
    records.append({'id':name,'runtime':rel(out),'derived_from':rel(src),'crop_ltrb':list(box),'size':[256,64],'mode':'RGB','operation':'crop and nearest-neighbor resize only','color_space':'sRGB','wrap_policy':'repeat U candidate; clamp V; test horizontal seam','seamless_certified':False,'sha256':checksum(out)})

# Contact sheet: preview only, deliberately labeled, never bind as a material.
sheet=Image.new('RGB',(840,1002),(27,30,27));d=ImageDraw.Draw(sheet)
d.text((16,14),'RUINS / MATERIAL & FOLIAGE CONTACT SHEET',font=font,fill=(236,221,187))
for i,name in enumerate(mat_names+leaf_names):
    x=12+(i%3)*276;y=46+(i//3)*316
    folder='materials' if name in mat_names else 'foliage'
    im=Image.open(RUNTIME/folder/(name+'.png'))
    if im.mode=='RGBA':
        bg=checker(im.size);bg.paste(im,(0,0),im);im=bg
    sheet.paste(im,(x,y))
    d.text((x,y+263),name.replace('_basecolor','').replace('_rgba',''),font=font,fill=(236,221,187))
    d.text((x,y+284),'256 px | '+('RGB' if folder=='materials' else 'native RGBA, checker preview'),font=small,fill=(172,178,160))
d.text((16,982),'AI base-color candidates. Not certified seamless. Guide images are not metric projections.',font=small,fill=(190,194,180))
sheet.save(QA/'asset_contact_sheet.png')

# Each square is an unmodified 2x2 repeated runtime image. Central seams are real.
repeat=Image.new('RGB',(1584,1122),(27,30,27));d=ImageDraw.Draw(repeat)
d.text((12,12),'2x2 REPEAT QA / CENTRAL EDGES ARE REAL / NOT CERTIFIED SEAMLESS',font=font,fill=(236,221,187))
for i,name in enumerate(mat_names[:6]):
    im=Image.open(RUNTIME/'materials'/(name+'.png'))
    x=12+(i%3)*524;y=40+(i//3)*540
    for dx in [0,256]:
        for dy in [0,256]:repeat.paste(im,(x+dx,y+dy))
    d.text((x,y+515),name.replace('_basecolor',''),font=font,fill=(236,221,187))
repeat.save(QA/'material_repeat_2x2.png')

guide=ROOT/'guides'/'modular_orthographic_style_reference.png';g=Image.open(guide)
manifest={'schema_version':1,'reference':'reference/source_concept.png','generator':'Built-in image_gen.imagegen, one separate call per master','runtime_transform_authorization':'User approved crop/resize; masters preserved byte-for-byte','notes':['Stylized base-color artwork, not measured PBR capture. Painted crevice and bevel contrast remains despite neutral-light prompting.','No maps are certified seamless; edge MAD is diagnostic, not a seam quality score.','Native alpha verified on foliage. Runtime alpha preserved by nearest-neighbor resize; alpha-tested silhouette must still be reviewed in engine.','The AI orthographic-style sheet is a visual concept guide, not dimensionally exact or mutually registered projections.'], 'assets':records,'guide':{'path':rel(guide),'size':list(g.size),'mode':g.mode,'metric':False,'sha256':checksum(guide)}}
(ROOT/'asset_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'assets':len(records),'manifest':rel(ROOT/'asset_manifest.json'),'qa':[rel(QA/'asset_contact_sheet.png'),rel(QA/'material_repeat_2x2.png')]},indent=2))
