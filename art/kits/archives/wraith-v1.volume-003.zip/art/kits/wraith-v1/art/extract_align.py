#!/usr/bin/env python3
"""Mechanically isolate native imagegen sprites, then align/resize without repainting.
User approved automated cropping/resizing. Original source files remain unchanged.
"""
from __future__ import annotations
import argparse, json, math
from pathlib import Path
import numpy as np
from scipy import ndimage
from PIL import Image, ImageDraw

HERE=Path(__file__).resolve().parent
SOURCES={'front': 'front-source-v1.png', 'back': 'back-source-v1.png', 'left': 'left-source-v1.png', 'right': 'right-source-v1.png'}
ACTIONS=['hover','claw_swipe','spectral_reach','wail_cast']
FPS={'hover':8,'claw_swipe':10,'spectral_reach':10,'wail_cast':8}
HITS={'hover':[],'claw_swipe':[3],'spectral_reach':[3],'wail_cast':[3]}
CORE_ALPHA=32
MIN_MAIN_AREA=2000
DETAIL_RADIUS=14
FRINGE_RADIUS=4
PIVOT=(128,232)
SIZE=256
MARGIN=12

def analyze(path:Path):
    im=Image.open(path).convert('RGBA'); rgba=np.asarray(im); alpha=rgba[:,:,3]
    core=alpha>CORE_ALPHA
    labels,n=ndimage.label(core,structure=np.ones((3,3),dtype=np.uint8))
    sizes=np.bincount(labels.ravel())
    mainids=np.flatnonzero(sizes>=MIN_MAIN_AREA);mainids=mainids[mainids!=0]
    if len(mainids)!=24:raise ValueError(f'{path}: expected 24 large components, got {len(mainids)}')
    major=np.where(np.isin(labels,mainids),labels,0)
    dist,indices=ndimage.distance_transform_edt(major==0,return_indices=True)
    nearest=major[tuple(indices)]
    # Keep meaningful disconnected specks/details only near a major character.
    detail=core & (dist<=DETAIL_RADIUS)
    detail_owner=np.where(detail,nearest,0)
    # Original antialias/translucency is retained in a four-pixel fringe.
    fringe_dist,fringe_indices=ndimage.distance_transform_edt(~detail,return_indices=True)
    owner=detail_owner[tuple(fringe_indices)]
    retained=(alpha>0)&(fringe_dist<=FRINGE_RADIUS)&(owner!=0)
    records=[]
    for label in mainids:
        yy,xx=np.nonzero(major==label)
        records.append({'label':int(label),'centroid':(float(xx.mean()),float(yy.mean()))})
    records.sort(key=lambda r:r['centroid'][1])
    sortedrecords=[]
    for row in range(4):
        group=sorted(records[row*6:row*6+6],key=lambda r:r['centroid'][0])
        for col,r in enumerate(group):r.update(row=row,column=col);sortedrecords.append(r)
    for r in sortedrecords:
        y,x=np.nonzero(major==r['label']); top,bottom=int(y.min()),int(y.max())+1
        low=y>=top+0.7*(bottom-top)
        weights=alpha[y[low],x[low]].astype(float)
        anchor_x=float(np.average(x[low],weights=weights))
        selected=retained&(owner==r['label'])
        sy,sx=np.nonzero(selected)
        box=(int(sx.min()),int(sy.min()),int(sx.max())+1,int(sy.max())+1)
        # Bounding bottom includes retained translucent edges so nothing extends below pivot.
        anchor_y=float(box[3])
        crop=np.array(rgba[box[1]:box[3],box[0]:box[2]],copy=True)
        mask=selected[box[1]:box[3],box[0]:box[2]]
        crop[~mask]=0
        r.update(source_bounds=list(box),source_anchor=[anchor_x,anchor_y],solid_bounds=[int(x.min()),top,int(x.max())+1,bottom],source_main_pixels=int(len(x)),retained_pixels=int(mask.sum()),crop=Image.fromarray(crop,'RGBA'))
    occupied=np.count_nonzero(alpha)
    summary={'path':path.name,'size':list(im.size),'mode':im.mode,'alpha_extrema':[int(alpha.min()),int(alpha.max())],'nonzero_alpha_pixels':int(occupied),'retained_alpha_pixels':int(retained.sum()),'discarded_faint_or_remote_pixels':int(occupied-retained.sum()),'main_components':24,'strong_alpha_touching_canvas_edges':bool(core[0,:].any() or core[-1,:].any() or core[:,0].any() or core[:,-1].any()),'records':[{k:v for k,v in r.items() if k!='crop'} for r in sortedrecords]}
    return sortedrecords,summary

def scale_limit(records):
    limits=[]
    for r in records:
        x0,y0,x1,y1=r['source_bounds'];x,y=r['source_anchor']
        limits.extend([(PIVOT[0]-MARGIN)/(x-x0),(SIZE-MARGIN-PIVOT[0])/(x1-x),(PIVOT[1]-MARGIN)/(y-y0)])
    # Reserve one extra pixel for rounding during resize/paste.
    return math.floor(min(limits)*1000)/1000-0.003

def bounds(img):
    return img.getchannel('A').getbbox()

def main():
    global SOURCES
    ap=argparse.ArgumentParser()
    ap.add_argument('--analyze-only',action='store_true')
    ap.add_argument('--source-dir',type=Path,default=HERE)
    ap.add_argument('--output-dir',type=Path)
    ap.add_argument('--sources-json',type=Path,help='JSON object mapping front/back/left/right to source PNG basenames')
    ap.add_argument('--asset',default='wraith')
    args=ap.parse_args()
    if args.sources_json:SOURCES=json.loads(args.sources_json.read_text())
    source_dir=args.source_dir.resolve()
    analyses={};allrecords={}
    for direction,filename in SOURCES.items():
        allrecords[direction],analyses[direction]=analyze(source_dir/filename)
    scale=scale_limit([r for v in allrecords.values() for r in v])
    analysis={'segmentation':{'core_alpha_strictly_greater_than':CORE_ALPHA,'main_minimum_area':MIN_MAIN_AREA,'nearby_detail_radius_pixels':DETAIL_RADIUS,'preserved_original_alpha_fringe_pixels':FRINGE_RADIUS},'global_scale':scale,'sources':analyses}
    (source_dir/'raw_analysis.json').write_text(json.dumps(analysis,indent=2))
    if args.analyze_only:
        print(json.dumps({'global_scale':scale,'sources':{k:{a:v[a] for a in ['main_components','alpha_extrema','strong_alpha_touching_canvas_edges']} for k,v in analyses.items()}},indent=2));return
    out=args.output_dir.resolve() if args.output_dir else source_dir/'extracted'
    for sub in ['frames256','frames128','atlases256','atlases128','previews']:(out/sub).mkdir(parents=True,exist_ok=True)
    metadata={'schema':'enemy-animation-kit-v1','asset':args.asset,'views':{'front':'down / toward camera','back':'up / away from camera','left':'screen left','right':'screen right'},'format':'RGBA PNG','frame_count':96,'master_size':[256,256],'runtime_size':[128,128],'pivot_pixels_master':list(PIVOT),'pivot_normalized':[PIVOT[0]/256,PIVOT[1]/256],'global_source_to_master_scale':scale,'anchor_method':'alpha-weighted horizontal centroid of the lowest 30% of each major connected body; bottom of retained robe alpha bounds anchored at robe-bottom pivot, not foot contact','source_processing':'Connected-component isolation at alpha >32; include nearby solid details within 14px; preserve original alpha in a 4px fringe. Remove unrelated low-alpha haze. No artwork painted, no per-frame fit or shape deformation. One global rescale for all views and actions.','animation_notes':'Frames are generated 2D poses, not a rigged/physically verified gait. Side-view attacks sometimes rotate toward three-quarter view. Speeds and attack-hit frames are proposed gameplay placeholders, not detected physics; engine movement/collision is separate. Idle can reuse walk frame 0; this is not an additional generated pose.','animations':{},'frames':{}}
    qa=[]
    contact=Image.new('RGB',(6*256,4*4*256),(25,29,33))
    for di,(direction,records) in enumerate(allrecords.items()):
        atlas=Image.new('RGBA',(6*256,4*256))
        atlas128=Image.new('RGBA',(6*128,4*128))
        peraction={a:[] for a in ACTIONS}
        native_dir=out/'native'/direction
        native_dir.mkdir(parents=True,exist_ok=True)
        for r in records:
            row,col=r['row'],r['column'];action=ACTIONS[row];name=f'{direction}_{action}_{col:02d}'
            crop=r['crop']
            (native_dir/action).mkdir(parents=True,exist_ok=True)
            crop.save(native_dir/action/f'{col:02d}.png')
            w=max(1,round(crop.width*scale));h=max(1,round(crop.height*scale))
            resized=crop.resize((w,h),Image.Resampling.LANCZOS)
            ox=round(PIVOT[0]-(r['source_anchor'][0]-r['source_bounds'][0])*scale)
            oy=PIVOT[1]-h
            if min(ox,oy)<0 or ox+w>256 or oy+h>256:raise ValueError(f'clipped sprite {name}: {(ox,oy,w,h)}')
            frame=Image.new('RGBA',(256,256));frame.alpha_composite(resized,(ox,oy))
            small=frame.resize((128,128),Image.Resampling.LANCZOS)
            frame.save(out/'frames256'/f'{name}.png');small.save(out/'frames128'/f'{name}.png')
            atlas.paste(frame,(col*256,row*256));atlas128.paste(small,(col*128,row*128))
            b=bounds(frame);margin=[b[0],b[1],256-b[2],256-b[3]]
            qa.append({'name':name,'alpha_bounds':list(b),'margins_ltrb':margin,'touches_frame_edge':min(margin)==0})
            peraction[action].append(frame)
            metadata['frames'][name]={'index':col,'view':direction,'action':action,'native':f'native/{direction}/{action}/{col:02d}.png','native_size':[crop.width,crop.height],'native_pivot':[round(r['source_anchor'][0]-r['source_bounds'][0],3),round(r['source_anchor'][1]-r['source_bounds'][1],3)],'master':f'frames256/{name}.png','runtime':f'frames128/{name}.png','atlas256':f'atlases256/{direction}.png','rect256':[col*256,row*256,256,256],'atlas128':f'atlases128/{direction}.png','rect128':[col*128,row*128,128,128],'pivot256':list(PIVOT),'pivot128':[64,116],'source':SOURCES[direction],'source_bounds':r['source_bounds'],'source_anchor':[round(v,3) for v in r['source_anchor']],'alpha_bounds256':list(b),'duration_ms':round(1000/FPS[action])}
        atlas.save(out/'atlases256'/f'{direction}.png');atlas128.save(out/'atlases128'/f'{direction}.png')
        contact.paste(atlas,(0,di*1024),atlas)
        for action,frames in peraction.items():
            key=f'{direction}_{action}'
            metadata['animations'][key]={'frames':[f'{direction}_{action}_{i:02d}' for i in range(6)],'fps':FPS[action],'loop':action=='hover','suggested_hit_frames_zero_based':HITS[action],'return_to':'hover' if action!='hover' else None}
            gifframes=[]
            for frame in frames:
                bg=Image.new('RGB',(256,256),(28,33,40));bg.paste(frame,(0,0),frame)
                dr=ImageDraw.Draw(bg);dr.line((8,233,248,233),fill=(50,58,64));gifframes.append(bg)
            gifframes[0].save(out/'previews'/f'{key}.gif',save_all=True,append_images=gifframes[1:],duration=round(1000/FPS[action]),loop=0,disposal=2)
    draw=ImageDraw.Draw(contact)
    for di,direction in enumerate(SOURCES):
        for ri,action in enumerate(ACTIONS):
            for ci in range(6):
                draw.text((ci*256+8,(di*4+ri)*256+8),f'{direction} / {action} / {ci}',fill=(220,225,230))
    contact.save(out/'previews'/'all_frames_contact.png')
    # Synchronized four-view previews; previews only have opaque background/labels.
    for actions,basename in [(['hover'],'hover_four_views'),(ACTIONS[1:],'attacks_four_views')]:
        previewframes=[]
        for fi in range(6):
            preview=Image.new('RGB',(4*256,len(actions)*256),(28,33,40));draw=ImageDraw.Draw(preview)
            for ci,direction in enumerate(SOURCES):
                for ri,action in enumerate(actions):
                    frame=Image.open(out/'frames256'/f'{direction}_{action}_{fi:02d}.png')
                    preview.paste(frame,(ci*256,ri*256),frame)
                    draw.line((ci*256+8,ri*256+233,ci*256+248,ri*256+233),fill=(50,58,64))
                    draw.text((ci*256+8,ri*256+8),f'{direction} / {action} / {fi}',fill=(220,225,230))
            previewframes.append(preview)
        previewframes[0].save(out/'previews'/f'{basename}.gif',save_all=True,append_images=previewframes[1:],duration=125,loop=0,disposal=2)
        previewframes[0].save(out/'previews'/f'{basename}.png')
    (out/'manifest.json').write_text(json.dumps(metadata,indent=2))
    # Exact atlas/frame equivalence also checks hidden RGB under zero alpha.
    cached_atlases={}
    for frame in metadata['frames'].values():
        for sz,field in [(256,'master'),(128,'runtime')]:
            af=frame[f'atlas{sz}']
            if af not in cached_atlases:cached_atlases[af]=Image.open(out/af)
            x,y,w,h=frame[f'rect{sz}']
            tile=cached_atlases[af].crop((x,y,x+w,y+h))
            separate=Image.open(out/frame[field])
            if tile.tobytes()!=separate.tobytes():raise ValueError(f'Atlas mismatch: {frame[field]}')
    qa_report={'all_192_atlas_tiles_byte_identical':True,'frame_count':len(qa),'global_scale':scale,'all_frames_rgba':True,'master_dimensions':[256,256],'runtime_dimensions':[128,128],'minimum_margins_ltrb':[min(q['margins_ltrb'][i] for q in qa) for i in range(4)],'frames_touching_edges':sum(q['touches_frame_edge'] for q in qa),'native_source_strong_alpha_edge_contacts':{k:v['strong_alpha_touching_canvas_edges'] for k,v in analyses.items()},'records':qa}
    (out/'extraction_qa.json').write_text(json.dumps(qa_report,indent=2))
    print(json.dumps({k:v for k,v in qa_report.items() if k!='records'},indent=2))

if __name__=='__main__':main()
