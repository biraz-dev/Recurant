# Smoldering undead — extracted animation assets

## Start here

- `manifest.json`: canonical frame paths, atlas rectangles, dimensions, pivots, animation order, FPS, and proposed attack hit frames.
- `frames128/`: 96 transparent 128 × 128 PNGs for lightweight runtime use.
- `frames256/`: the same 96 poses on transparent 256 × 256 canvases.
- `native/`: lossless-size extracted sprite cutouts, with crop-local pivots in the manifest. Use these if higher rendering resolution matters.
- `atlases128/{front,back,left,right}.png`: four 768 × 512 atlases; each has six columns and four rows of exact 128 × 128 tiles.
- `atlases256/{front,back,left,right}.png`: four 1536 × 1024 atlases; exact 256 × 256 tiles.
- `previews/walk_four_views.gif`, `previews/attacks_four_views.gif`: opaque preview animations; these are not game assets.
- `previews/all_frames_contact.png`: labelled visual audit of every pose.

## Import contract

File names use `{view}_{action}_{00..05}.png`. Views are `front` (down), `back` (up), `left`, and `right`. Atlas rows are `walk`, `claw_swipe`, `lunge`, `two_hand_slam`, in that order. Frame and hit-frame indices are **zero-based**.

Use pivot `(64,116)` for 128px frames or `(128,232)` for 256px frames, normalized `(0.5,0.90625)`. Position the pivot at the entity's ground position. A single global source-to-master scale of `0.495` is used across all directions/actions; frames are not independently stretched or resized to fill their bounds. The generous padding accommodates long lunges and claws. Standing bodies occupy about 120–130 pixels vertically on the 256px canvases, or 60–65 pixels on the 128px canvases.

Keep gameplay movement separate from sprite-frame animation: move the world entity using velocity/collision, select direction from its travel/facing vector, and play `walk` at the manifest FPS while moving. On stopping, use the first walk pose as an idle fallback. An attack plays once, optionally applies gameplay damage at its proposed hit-frame index, and then returns to movement or idle. `return_to: "walk"` in the manifest is an animation-family hint; choose the matching facing direction and the appropriate idle/moving state in code.

| Action | Frames | FPS | Loop | Proposed damage frame |
|---|---:|---:|---|---:|
| Walk | 6 | 8 | Yes | — |
| Claw swipe | 6 | 10 | No | 3 |
| Lunge | 6 | 10 | No | 3 |
| Two-hand slam | 6 | 8 | No | 4 |

Attack hit frames are placeholders for engine tuning, not measurements of a physics simulation. Preview GIFs repeat for convenient inspection even when the gameplay animation is non-looping.

## QA and limitations

All 96 poses exist in all three forms (native crop, 256px, 128px). Every master/runtime PNG is RGBA and has transparent margins. No master touches a frame edge. Native sources had 24 separate major sprite components per sheet and no strong-alpha content touching the outer sheet boundary. Raw source atlases were **not safe to slice blindly**; component-aware extraction preserves limbs extending beyond nominal source cells.

The extraction identifies bodies at alpha > 32, includes nearby disconnected details within 14 pixels, retains original alpha within a four-pixel edge fringe, and removes unrelated faint background haze. The ground/root anchor is a reproducible lower-body-centroid/bottom-alpha heuristic, not a rigged skeleton joint. This reduces import jitter but cannot repair the source animation's drawing variation.

These are generated prototype animations. Small anatomy and texture details drift, side attack torsos sometimes rotate toward three-quarter view, and the side walks can read as a shuffling gait. Review motion at intended in-game size before shipping. For exact root motion, hand-cleaned anatomy, or a perfectly mechanical walk cycle, further animation work is needed.

## Regenerate mechanical extraction

From the kit root, with Python packages Pillow, NumPy, and SciPy available:

```sh
python art/extract_align.py
```

Original native artwork, generation prompts, and provenance are preserved one directory above. See `extraction_qa.json`, `independent_qa.json`, and `../raw_analysis.json` for machine-readable checks.
