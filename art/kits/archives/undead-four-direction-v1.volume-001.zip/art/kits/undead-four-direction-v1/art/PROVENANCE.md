# Ember undead sprite artwork provenance

## Reference and generation

- Identity reference: `../133.png` (user-provided smoldering skeletal zombie).
- Generator: built-in `image_gen.imagegen`, not an API/CLI fallback.
- Five generation calls produced four selected directional sheets plus one retained superseded left-view sheet.
- Prompts are preserved in `prompts/`. Each call explicitly requested true transparency, a six-column/four-row atlas, the same unarmed character, restrained red-orange embers, and no flame plumes.
- The selected and superseded source sheets here are unchanged native generator outputs.

## Selected source images

| View | Selected source |
|---|---|
| Front / down-screen | `front-source-v1.png` |
| Back / up-screen | `back-source-v1.png` |
| Left | `left-source-v2.png` |
| Right | `right-source-v1.png` |

`left-source-v1.png` is retained but not selected. A targeted native image-generation correction improved its walk passing stance and side-facing attack orientation.

## Requested animation order

Rows are walk, claw swipe, forward lunge, and two-hand slam. Columns are six consecutive animation poses. The selected set contains 4 views × 4 actions × 6 poses = **96 unique requested frame positions**.

The walk rows are intended to loop. Attack rows progress from ready/anticipation through strike/impact to recovery. Timing and damage windows in the machine-readable manifest are proposed integration defaults, not physically measured events.

## Post-processing authorization

The sprites were mechanically cropped, aligned, and resized for straightforward engine integration; original source artwork is preserved.

Raster character artwork was created only by the built-in image generator. Subsequent Python/Pillow operations are mechanical alpha-aware extraction, uniform scaling, transparent padding, atlasing, and preview composition. No synthetic limbs, replacement poses, or painted corrections are introduced by code.

## Raw atlas QA

- All five native sheets are 1536 × 1024 RGBA PNGs.
- All have real alpha spanning 0–254. Brown RGB values under transparent pixels are not an opaque brown background.
- Each selected sheet contains 24 major full-body alpha components, arranged in six visual columns and four visual rows.
- The raw generator layout is **not an exact safe 256 × 256 tile grid**: poses can extend outside their nominal cells, and the implied foot baseline varies.
- Alpha-aware connected-component extraction is therefore used instead of blind cell cropping. Source files are preserved so extraction can be audited or repeated.
- Very faint-alpha background haze/specks are removed outside the local extraction fringe. Main body and edge alpha are retained; source alpha is not forced to fully opaque.

## Animation limitations

These are generated prototype animation sprites, not hand-cleaned or rig-derived production animations. The character identity and major attack silhouettes are consistent, but small anatomy/texture details vary across poses. Some side attack torsos turn slightly toward the camera. Side walk poses include limited leg alternation and can still read as a shuffling step rather than a perfectly biomechanical gait. Foot anchors and equal canvases address import jitter, not underlying drawing drift. Review preview loops in the target game and tune speed/hit timing before shipping.
