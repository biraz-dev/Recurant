#!/usr/bin/env python3
"""Deterministic, dependency-free modular ruins mesh authoring; metres, glTF Y-up.
Exports separate OBJ/MTL and glTF 2.0 GLB meshes with flat normals + explicit UV0.
GLBs intentionally contain flat-color PBR materials, not invented material maps.
Run: python meshes/generate_meshes.py
"""
from pathlib import Path
import json, math, struct, random
ROOT = Path(__file__).resolve().parent
MATERIALS = {
'M_Sandstone': {'color':[.52,.405,.255,1], 'roughness':.92, 'texture':'../art/runtime/256/materials/sandstone_blocks_basecolor.png'},
'M_Floor': {'color':[.43,.39,.28,1], 'roughness':.94, 'texture':'../art/runtime/256/materials/worn_floor_basecolor.png'},
'M_Carved': {'color':[.58,.46,.29,1], 'roughness':.9, 'texture':'../art/runtime/256/materials/sandstone_blocks_basecolor.png','note':'Safe planar-UV fallback. carved_trim_basecolor.png is a motif sheet, not a whole-sheet tile; requires custom face UVs. Trim strips need U-repeat / V-clamp.'},
'M_Rubble': {'color':[.39,.345,.25,1], 'roughness':1, 'texture':'../art/runtime/256/materials/rubble_stone_basecolor.png'},
'M_Water': {'color':[.08,.31,.30,.7], 'roughness':.22, 'texture':'../art/runtime/256/materials/water_basecolor.png'},
}
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def cross(a,b): return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def unit(a):
 n=math.sqrt(dot(a,a)); assert n>1e-10; return tuple(x/n for x in a)
class Mesh:
 def __init__(self,name,desc,pivot='base_center'):
  self.name,self.description,self.pivot=name,desc,pivot
  self.positions=[];self.normals=[];self.uvs=[];self.triangles=[];self.slots=[];self.components=[]
 def poly(self,pts,mat,center=None):
  n=unit(cross(sub(pts[1],pts[0]),sub(pts[2],pts[0])))
  if center is not None:
   centroid=tuple(sum(p[k] for p in pts)/len(pts) for k in range(3))
   if dot(n,sub(centroid,center))<0: pts=list(reversed(pts));n=tuple(-v for v in n)
  start=len(self.positions)
  axis=max(range(3),key=lambda k:abs(n[k]))
  # Planar projection per face, 1 texture repeat per 2 metres. Hard UV seams are intentional.
  axes={0:(2,1),1:(0,2),2:(0,1)}[axis]
  for p in pts:
   self.positions.append(p);self.normals.append(n);self.uvs.append((p[axes[0]]/2,p[axes[1]]/2))
  for j in range(1,len(pts)-1): self.triangles.append((start,start+j,start+j+1));self.slots.append(mat)
 def box(self,c,size,mat='M_Sandstone',bevel=.025,rotation=0):
  self.components.append({'center':c,'size':size,'yaw':rotation})
  h=tuple(s/2 for s in size);b=min(bevel,min(h)*.45)
  def xf(p):
   cs,sn=math.cos(rotation),math.sin(rotation)
   return (c[0]+p[0]*cs+p[2]*sn,c[1]+p[1],c[2]-p[0]*sn+p[2]*cs)
  def emit(p):self.poly([xf(q) for q in p],mat,c)
  if not b:
   for axis in range(3):
    other=[k for k in range(3) if k!=axis]
    for s in [-1,1]:
     p=[]
     for s1,s2 in [(-1,-1),(1,-1),(1,1),(-1,1)]:
      q=[0,0,0];q[axis]=s*h[axis];q[other[0]]=s1*h[other[0]];q[other[1]]=s2*h[other[1]];p.append(q)
     emit(p)
   return
  # Six main faces, twelve chamfer quads, eight corner triangles = 44 triangles.
  for axis in range(3):
   other=[k for k in range(3) if k!=axis]
   for s in [-1,1]:
    p=[]
    for s1,s2 in [(-1,-1),(1,-1),(1,1),(-1,1)]:
     q=[0,0,0];q[axis]=s*h[axis];q[other[0]]=s1*(h[other[0]]-b);q[other[1]]=s2*(h[other[1]]-b);p.append(q)
    emit(p)
  for a,baxis in [(0,1),(0,2),(1,2)]:
   k=3-a-baxis
   for sa in [-1,1]:
    for sb in [-1,1]:
     p=[]
     for full,sk in [(a,-1),(baxis,-1),(baxis,1),(a,1)]:
      q=[0,0,0];q[a]=sa*(h[a]-(0 if full==a else b));q[baxis]=sb*(h[baxis]-(0 if full==baxis else b));q[k]=sk*(h[k]-b);p.append(q)
     emit(p)
  for sx in [-1,1]:
   for sy in [-1,1]:
    for sz in [-1,1]:
     signs=[sx,sy,sz];p=[]
     for full in range(3):p.append(tuple(signs[k]*(h[k]-(0 if full==k else b)) for k in range(3)))
     emit(p)
 def bounds(self):
  return {'min':[min(v[k] for v in self.positions) for k in range(3)],'max':[max(v[k] for v in self.positions) for k in range(3)]}
 def validate(self):
  assert len(self.positions)==len(self.normals)==len(self.uvs)
  assert 0<len(self.triangles)<500
  assert len(self.triangles)==len(self.slots)
  for a in self.positions+self.normals+self.uvs:assert all(math.isfinite(v) for v in a)
  for n in self.normals:assert abs(dot(n,n)-1)<1e-5
  for t in self.triangles:
   assert min(t)>=0 and max(t)<len(self.positions)
   n=cross(sub(self.positions[t[1]],self.positions[t[0]]),sub(self.positions[t[2]],self.positions[t[0]]))
   assert math.sqrt(dot(n,n))>1e-8
   assert dot(n,self.normals[t[0]])>0
  assert set(self.slots)<=MATERIALS.keys()
 def export_obj(self):
  lines=['# Modular base geometry; not a reconstruction or final sculpt.','# Metres. +Y up, local -Z forward. Explicit UV0; one repeat per 2 metres.',f'mtllib {self.name}.mtl',f'o {self.name}']
  for p in self.positions:lines.append('v '+' '.join(f'{x:.7f}' for x in p))
  for uv in self.uvs:lines.append('vt '+' '.join(f'{x:.7f}' for x in uv))
  for n in self.normals:lines.append('vn '+' '.join(f'{x:.7f}' for x in n))
  last=None
  for t,mat in zip(self.triangles,self.slots):
   if mat!=last:lines.append('usemtl '+mat);last=mat
   lines.append('f '+' '.join(f'{v+1}/{v+1}/{v+1}' for v in t))
  (ROOT/f'{self.name}.obj').write_text('\n'.join(lines)+'\n')
  lines=['# Deliberately untextured. Optional texture bindings: MATERIAL_BINDINGS.json']
  for mat in sorted(set(self.slots)):
   col=MATERIALS[mat]['color'];lines+=['newmtl '+mat,'Ka 0.000 0.000 0.000','Kd '+' '.join(str(x) for x in col[:3]),'Ks 0.000 0.000 0.000','d '+str(col[3]),'illum 2','']
  (ROOT/f'{self.name}.mtl').write_text('\n'.join(lines))
 def export_glb(self):
  binary=bytearray();views=[];accessors=[]
  def add(values,fmt,ctype,typ,target,bounds=False):
   while len(binary)%4:binary.append(0)
   offset=len(binary)
   for row in values:
    if not isinstance(row,(tuple,list)):row=(row,)
    binary.extend(struct.pack('<'+fmt,*row))
   view=len(views);views.append({'buffer':0,'byteOffset':offset,'byteLength':len(binary)-offset,'target':target})
   acc={'bufferView':view,'componentType':ctype,'count':len(values),'type':typ}
   if bounds:acc.update(min=[min(row[k] for row in values) for k in range(3)],max=[max(row[k] for row in values) for k in range(3)])
   index=len(accessors);accessors.append(acc);return index
  pos=add(self.positions,'fff',5126,'VEC3',34962,True);nor=add(self.normals,'fff',5126,'VEC3',34962);uv=add(self.uvs,'ff',5126,'VEC2',34962)
  material_names=sorted(set(self.slots));materials=[];primitives=[]
  for mi,mat in enumerate(material_names):
   data=MATERIALS[mat]
   materials.append({'name':mat,'pbrMetallicRoughness':{'baseColorFactor':data['color'],'metallicFactor':0,'roughnessFactor':data['roughness']},'alphaMode':'BLEND' if mat=='M_Water' else 'OPAQUE','doubleSided':mat=='M_Water','extras':{'bindingNote':'Untextured placeholder; see MATERIAL_BINDINGS.json'}})
   indices=[i for t,s in zip(self.triangles,self.slots) if s==mat for i in t]
   ind=add(indices,'H',5123,'SCALAR',34963)
   primitives.append({'attributes':{'POSITION':pos,'NORMAL':nor,'TEXCOORD_0':uv},'indices':ind,'material':mi,'mode':4})
  data={'asset':{'version':'2.0','generator':'Ruins modular-base kit deterministic authoring script'},'scene':0,'scenes':[{'name':self.name,'nodes':[0]}],'nodes':[{'name':self.name,'mesh':0,'extras':{'pivot':self.pivot,'units':'metres'}}],'meshes':[{'name':self.name,'primitives':primitives}],'materials':materials,'buffers':[{'byteLength':len(binary)}],'bufferViews':views,'accessors':accessors,'extras':{'description':self.description,'basis':'+Y up, -Z forward','uvScale':'1 repeat per 2m; projected per face','notIncluded':['collision meshes','lightmap UV1','rigs','LODs','tangents','final sculpture']}}
  js=json.dumps(data,separators=(',',':')).encode();js+=b' '*((-len(js))%4);binary+=b'\0'*((-len(binary))%4)
  result=struct.pack('<4sII',b'glTF',2,12+8+len(js)+8+len(binary))+struct.pack('<I4s',len(js),b'JSON')+js+struct.pack('<I4s',len(binary),b'BIN\0')+binary
  (ROOT/f'{self.name}.glb').write_bytes(result)
  return len(result)
def modules():
 out=[]
 m=Mesh('ruins_floor_2m','Four lightly chamfered floor slabs; top Y=0.','top_center')
 for x in [-.5015,.5015]:
  for z in [-.5015,.5015]:m.box((x,-.1,z),(.997,.2,.997),'M_Floor',.014)
 out.append(m)
 m=Mesh('ruins_wall_2m','Four coursed sandstone blocks; 2m width, 4m height, 0.4m depth.')
 for r in range(4):
  low=r+(.003 if r>0 else 0); high=r+1-(.003 if r<3 else 0)
  m.box((0,(low+high)/2,0),(2,high-low,.4),'M_Sandstone',.018)
 out.append(m)
 m=Mesh('ruins_column_4m','Square shaft with broad base and capital; 1m maximum width.')
 m.box((0,.2,0),(1,.4,1));m.box((0,2,0),(.7,3.2,.7));m.box((0,3.8,0),(1,.4,1),'M_Carved')
 out.append(m)
 m=Mesh('ruins_doorway_4m','Open doorway; outer width4m, height4m; unobstructed opening3m by3m.')
 for x in [-1.75,1.75]:
  m.box((x,.2,0),(.5,.4,1));m.box((x,1.5,0),(.5,2.2,.75));m.box((x,2.8,0),(.5,.4,1),'M_Carved')
 m.box((0,3.5,0),(4,1,1),'M_Carved')
 out.append(m)
 m=Mesh('ruins_rail_2m','Low stone parapet; 2m wide, 0.6m high, 0.3m deep.')
 m.box((0,.3,0),(2,.6,.3),'M_Sandstone',.02);out.append(m)
 m=Mesh('ruins_bridge_deck_2m','Four chamfered deck slabs; 2m wide, 2m long, topY0. No railings.','top_center')
 for x in [-.5015,.5015]:
  for z in [-.5015,.5015]:m.box((x,-.2,z),(.997,.4,.997),'M_Floor',.016)
 out.append(m)
 m=Mesh('ruins_stairs_2m_rise06','Three closed risers; totalrise0.6m/run2m. Ascent toward local-Z. Bottom-front-center pivot.','bottom_front_center')
 # Each cuboid meets its neighbours; bottom-front center at (0,0,0).
 for i in range(3):
  h=(i+1)*.2;m.box((0,h/2,-(i+.5)*2/3),(2,h,2/3),'M_Floor',0)
 out.append(m)
 m=Mesh('ruins_rubble_1m','Four deterministic loose stone chunks; scatter prop, not a structural unit.')
 m.box((-.23,.19,-.15),(.62,.38,.52),'M_Rubble',.07,.15)
 m.box((.24,.16,.21),(.48,.32,.55),'M_Rubble',.07,-.22)
 m.box((.05,.51,-.09),(.54,.33,.48),'M_Rubble',.08,.47)
 m.box((-.3,.13,.33),(.3,.26,.34),'M_Rubble',.06,-.3)
 out.append(m)
 m=Mesh('ruins_water_2m','Single2m square water plane; no wave displacement or shader simulation.','surface_center')
 m.poly([(-1,0,-1),(-1,0,1),(1,0,1),(1,0,-1)],'M_Water');out.append(m)
 m=Mesh('ruins_statue_plinth_4m','Pedestal only, NOT a sculpted statue. 4m square shallow ceremonial dais.')
 m.box((0,.1,0),(4,.2,4),'M_Carved');m.box((0,.3,0),(3.8,.2,3.8),'M_Sandstone');out.append(m)
 m=Mesh('ruins_statue_proxy','ABSTRACT SEATED HUMANOID BLOCKOUT ONLY. No sculpt, iconography, face, rig or historical reconstruction.')
 m.box((0,.65,.2),(1.5,.7,1),'M_Carved',.09)
 for x in [-.5,.5]:
  m.box((x,.8,-.55),(.58,.35,1.0),'M_Carved',.07)
  m.box((x,.45,-.85),(.65,.9,.7),'M_Carved',.08)
 m.box((0,1.65,.2),(1.35,1.5,.75),'M_Carved',.1)
 m.box((0,2.9,.1),(.8,1,.8),'M_Carved',.12)
 m.box((0,3.5,.1),(.95,.2,.95),'M_Carved',.05)
 for x in [-.85,.85]:m.box((x,1.4,-.05),(.3,1.3,.5),'M_Carved',.06)
 m.positions=[(x,y,z+.25) for x,y,z in m.positions]
 for c in m.components:c['center']=(c['center'][0],c['center'][1],c['center'][2]+.25)
 out.append(m)
 return out

def main():
 assets=[]
 for m in modules():
  m.validate();m.export_obj();n=m.export_glb()
  a=m.bounds();size=[a['max'][k]-a['min'][k] for k in range(3)]
  assets.append({'id':m.name,'description':m.description,'files':{'glb':m.name+'.glb','obj':m.name+'.obj','mtl':m.name+'.mtl'},'pivot':m.pivot,'pivotLocal':[0,0,0],'bounds':a,'dimensionsMeters':size,'vertices':len(m.positions),'triangles':len(m.triangles),'materialSlots':sorted(set(m.slots)),'glbBytes':n})
 manifest={'schema':'ruins-modular-geometry-v1','units':'meters','coordinateSystem':'right-handed, +Y up, local -Z forward, +X right','gridMeters':2,'uv0':'Planar per face, one texture repeat per2m; intentional seams. No lightmapUV1.','meshStatus':'Authored low-poly modular bases inspired by supplied reference; not an exact reconstruction.','assets':assets}
 (ROOT/'mesh_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 (ROOT/'MATERIAL_BINDINGS.json').write_text(json.dumps({'note':'Optional binding guide ONLY. GLB and MTL intentionally ship solid-color PBR placeholders and no texture references. Only use paths after file-existence verification.','baseColorColorSpace':'sRGB','normalColorSpace':'linear (no normal maps provided)','sampler':{'minFilter':9728,'magFilter':9728,'wrapS':10497,'wrapT':10497},'uvRepeatMeters':2,'onTextureBind':'Set material baseColor RGB factor to white, retaining water alpha0.7; otherwise placeholder color will darken the texture. Runtime256 textures are low-resolution candidates, not certified seamless.','materials':MATERIALS},indent=2)+'\n')
 print(json.dumps({'assets':len(assets),'triangles':sum(a['triangles'] for a in assets),'maxTriangles':max(a['triangles'] for a in assets),'validation':'passed source geometry checks'},indent=2))
if __name__=='__main__':main()
